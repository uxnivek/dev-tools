using System;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Serialization;
using ASB.CBO.Utility;
using System.Collections;



namespace ASBBank.FNC.BP.Balance
{
	/// <summary>
	/// Summary description for Alert.  
	/// </summary>
	/// 	

	#region Customer Alerts object 

	[Serializable]
	[XmlRoot("alertRequests")] 
	public class CustomerAlerts
	{	
		[XmlElement("alertRequest")]
		public AlertDetails[] AlertDetailsArray = null;
		
		public static CustomerAlerts Create(string xml)
		{
			return (CustomerAlerts)XmlHelper.Inflate(xml, typeof(CustomerAlerts));
		}	
		
		public string XML
		{
			get { return XmlHelper.Deflate(this); }
		}
	}


	[Serializable]
	public class AlertDetails
	{	
		private string _accountName;
		private string _alertAccount;
		private string _alertType;
		private string _alertLimit;
		private string _accountToShow;

		[XmlElement("alertAccount")]
		public string alertAccount
		{
			get { return _alertAccount;}
			set { _alertAccount = value; }
		}

		[XmlElement("alertType")]
		public string alertType
		{
			get { return _alertType;}
			set { _alertType = value; }			
		}

		[XmlElement("alertStatus")]
		public int alertStatus;

		[XmlElement("alertLimit")]
		public string alertLimit
		{
			get { return _alertLimit;}
			set { _alertLimit = value; }			
		}
		
		//accountName is not in returned XML so we populate it later.
		[XmlIgnore()]
		public string accountName
		{
			get { return _accountName; }
			set { _accountName = value; }
		}

		[XmlIgnore()]
		public string accountToShow
		{
			get { return _accountToShow; }
			set { _accountToShow = value; }
		}
	}
		#endregion	

	#region Alert Delivery Details object 
	
		[Serializable]
			[XmlRoot("alertDeliveryDetails")] 
			public class CustomerDeliveryDetails
		{	
			#region Properties

			[XmlElement("alertMedium")]
			public string alertMedium;		

			[XmlElement("alertAddress")]
			public string alertAddress;		

			[XmlElement("alertSuspended")]
			public string alertSuspended;
		
			[XmlElement("alertFeeAccount")]
			public string alertFeeAccount;

			[XmlElement("alertFeeExempt")]
			public string alertFeeExempt;

			#endregion

			public static CustomerDeliveryDetails Create(string xml)
			{
				return (CustomerDeliveryDetails)XmlHelper.Inflate(xml, typeof(CustomerDeliveryDetails));
			}

			public string XML
			{
				get { return XmlHelper.Deflate(this); }
			}	
		}
	
		#endregion

	#region Alert Types

	[Serializable]
	public class AlertType
	{	
		private int _typeId;
		private string _alertTypeDesc;
		private string _alertLimit = string.Empty;
		private bool _selected;
		private string _alertAccount;

		public AlertType(int typeId, string alertTypeDesc) 
		{
			this.typeId = typeId;
			this.alertTypeDesc = alertTypeDesc;
		}
		
		public int typeId		
		{
			get { return _typeId;}
			set { _typeId = value; }
		}

		public string alertTypeDesc
		{ 
			get { return _alertTypeDesc; }
			set {_alertTypeDesc = value; }
		}

		public string alertLimit
		{
			get { return _alertLimit; }
			set { _alertLimit = value; }
		}	

		public bool selected
		{
			get { return _selected;}
			set {_selected = value;}
		}

		public string alertAccount
		{
			get { return _alertAccount;}
			set { _alertAccount = value;}
		}
	}		

	#endregion

	#region Personalised Accounts

	[Serializable]
	public class PersonalisedAccounts
	{			
		private string _alertAccount;
		private string _personalisedAccount;

		public PersonalisedAccounts(string alertAccount, string personalisedAccount) 
		{
			this.alertAccount = alertAccount;
			this.personalisedAccount = personalisedAccount;
		}

		public string alertAccount
		{
			get { return _alertAccount;}
			set { _alertAccount = value;}
		}

		public string personalisedAccount
		{ 
			get { return _personalisedAccount; }
			set {_personalisedAccount = value; }
		}
	}		

	#endregion
	

	#region AlertEdit classes

	[Serializable]
	public class AlertEdit
	{
		private int _alertType;
		private string _alertLimitNew = string.Empty;
		private string _alertLimitOld = string.Empty;
		private bool _alertSelectedNew;
		private bool _alertSelectedOld;
		private string _alertAction;
		private string _alertAccountOld;
		private string _alertAccountNew;

		public AlertEdit(int alertType) 
		{
			this.alertType = alertType;
		}

		public int alertType
		{
			get { return _alertType;}
			set {_alertType = value;}
		}

		public string alertLimitNew
		{
			get { return _alertLimitNew;}
			set {_alertLimitNew = value;}
		}
	
		public string alertLimitOld
		{
			get { return _alertLimitOld;}
			set {_alertLimitOld = value;}
		}

		public bool alertSelectedNew
		{
			get { return _alertSelectedNew;}
			set {_alertSelectedNew = value;}
		}

		public bool alertSelectedOld
		{
			get { return _alertSelectedOld;}
			set {_alertSelectedOld = value;}
		}

		public string alertAction
		{
			get { return _alertAction;}
			set {_alertAction = value;}
		}

		public string alertAccountOld
		{
			get { return _alertAccountOld;}
			set { _alertAccountOld = value;}
		}

		public string alertAccountNew
		{
			get { return _alertAccountNew;}
			set { _alertAccountNew = value;}
		}
	}

	[Serializable]
		public class AlertEditArray : ArrayList 
	{
		public AlertEditArray()
		{
			this.Clear();
//			this.Add(new AlertEdit("44301"));
//			this.Add(new AlertEdit("44302"));
//			this.Add(new AlertEdit("44303"));
//			this.Add(new AlertEdit("44304"));
		}
	
		public void InitNewValues()
		{			
			foreach(AlertEdit oAlertEdit in this)
			{
				oAlertEdit.alertLimitNew = "";
				oAlertEdit.alertSelectedNew = false;
			}			
		}
	}
	#endregion	

}
