using System;
using System.EnterpriseServices;

namespace ASBBank.FNC.BP.Balance
{
	/// <summary>
	/// Summary description for ATMFavourite.
	/// </summary>
	public class ATMFavourite
	{
		public ATMFavourite()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static string SaveProfile(string sAppID, string sChannelID, string sCardID, 
			string sAccount, string sSuffix, int iAmount, string sReceipt)
		{
			string sResult;
						
			ASB.BC.Customer.IATMFavourite_2008_4 oATM = null;
			
			try
			{
				oATM = new ASB.BC.Customer.ATMFavourite();

				sResult = oATM.SaveConsumerProfile(sAppID, sChannelID, sCardID, sAccount, sSuffix, 
					iAmount, sReceipt);
				
			}
			finally
			{
				if (oATM != null)
					ServicedComponent.DisposeObject((ServicedComponent)oATM);
			}

			return sResult;
		}

		public static string DeleteProfile(string sAppID, string sChannelID, string sCardID)
		{
			string sResult;

			ASB.BC.Customer.IATMFavourite_2008_4 oATM = null;

			try
			{
				oATM = new ASB.BC.Customer.ATMFavourite();

				sResult = oATM.DeleteConsumerProfile(sAppID, sChannelID, sCardID);
			}
			finally
			{
				if(oATM != null)
					ServicedComponent.DisposeObject((ServicedComponent)oATM);
			}

			return sResult;
		}


		public static string RetrieveProfile(string sAppID, string sChannelID, string sCardID, out string sResultXML)
		{
			string sResult;

			ASB.BC.Customer.IATMFavourite_2008_4 oATM = null;

			try
			{
				oATM = new ASB.BC.Customer.ATMFavourite();

				sResult = oATM.GetConsumerProfile(sAppID, sChannelID, sCardID, out sResultXML);
			}
			finally
			{
				if(oATM != null)
					ServicedComponent.DisposeObject((ServicedComponent)oATM);
			}

			return sResult;
		}

	}
}
