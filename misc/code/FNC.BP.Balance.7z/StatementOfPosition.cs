using System;
using ASB.Utility.Common;
using System.Data;
using System.Xml;
using System.Collections;
using ASBBank.FNC.BPCommon;

namespace ASBBank.FNC.BP.Balance
{
	/// <summary>
	/// A class for retrieving StatementOfPosition for straight through processing application
	/// </summary>
	public class StatementOfPosition
	{
	
		/// <summary>
		///  Get Statement of Position for the specified customer for a straight through processing application.
		/// </summary>
		/// <param name="sessionGUID"></param>
		/// <param name="appId"></param>
		/// <param name="channelId"></param>
		/// <param name="bankNumber"></param>
		/// <param name="customerNumber"></param>
		/// <param name="hostUserName"></param>
		/// <param name="sop"></param>
		/// <returns></returns>
		public static string Get(string sessionGUID, string appId, string channelId,
			string bankNumber, string customerNumber, string hostUserName, out SOPDataSet sop)
		{
			string returnString = null;
			string result;
			string outputXml;
			ArrayList uniqueAcctList;
			
			//1. Initialise return Statement of Position dataset 
			sop = new SOPDataSet();

			//2. Get the cached CPI result from session, or do a call if cached result does not exist.
			result = Balance.GetProductsByCustomer(sessionGUID, appId, channelId, bankNumber, customerNumber, 
				hostUserName, out outputXml, true);			
			if (result != Constants.SUCCESS)  //If CPI call fails, we cannot carry on, hence quit.
				return result;

			XmlDocument cpiDoc = new XmlDocument();
			cpiDoc.LoadXml(outputXml);

			//3. Populate Credit Cards
			PopulateCreditCards(cpiDoc, sop);

			//4. Get unqiue accounts owned by customer list to filter accounts returned from CPI call
			result = GetUniqueAccountsOwnedByCust(appId, channelId, hostUserName, bankNumber, customerNumber, out uniqueAcctList);
			if (result != Constants.SUCCESS)  //cannot carry on to load accounts, term loans etc. if this call fails, hence quit
				return result;

			//5. Populate Term Loans (Note - keep going even if error returns)
			result = PopulateTermLoans (appId, channelId, hostUserName, cpiDoc, uniqueAcctList,  sop);
			if (result != Constants.SUCCESS)
				returnString += result;

			//6. Populate from CPID section - this includes accounts, overdrafts, orbit and orbit fasttrack
			//(Note - keep going even if error returns)
			result = PopulateAccountsFromCPID(appId, channelId, hostUserName, cpiDoc, uniqueAcctList, sop);
			if (result != Constants.SUCCESS)
				returnString += result;

			//7. Populate Investments
			PopulateInvestments(cpiDoc, uniqueAcctList, sop);
			if (result != Constants.SUCCESS)
				returnString += result;

			if (returnString != null)
				return returnString;  //return all accumulated errors
			else
				return Constants.SUCCESS;
		}


		private static void PopulateCreditCards(XmlDocument cpiDoc, SOPDataSet sop)
		{
			XmlNodeList creditCardList;	
			creditCardList = Balance.ExtractCreditCardsFromCPIExcludeTrueReward(cpiDoc, false, false);

			foreach(XmlNode node in creditCardList)
			{
				string creditCardNumber;
				string productName;
				string ledgerBalanceString;
				string availableBalanceString;
				decimal ledgerBalance;
				decimal availableBalance;
				decimal creditLimit;
				string accountStatus;
				
				ledgerBalanceString = GetNodeValue(node, Balance.CPIConstants.CrCardLedgerBalAmt);
				availableBalanceString = GetNodeValue(node, Balance.CPIConstants.CrCardAvailableBalAmt);
				accountStatus = GetNodeValue(node, "AccountStatus");

				//Exclude closed/cancelled cards with zero balance   - TTW 66503
                bool bShowCardAccount = (accountStatus.Length > 0 && (ledgerBalanceString == "" ? 0 : Convert.ToInt64(ledgerBalanceString)) == 0) ? false : true;

				//only add the credit card if ledger balance/available balance has a value
				if (ledgerBalanceString != null && ledgerBalanceString != string.Empty &&
					availableBalanceString != null && availableBalanceString != string.Empty &&  bShowCardAccount)
				{
					creditCardNumber = GetNodeValue(node, Balance.CPIConstants.CrCardNumb);				
					ledgerBalance = decimal.Parse(ledgerBalanceString)/100;
					availableBalance = decimal.Parse(availableBalanceString)/100;
					creditLimit = ledgerBalance + availableBalance;
					productName = GetNodeValue(node, Balance.CPIConstants.ProdDescription);
                    if (accountStatus.Length > 0)
                        productName = productName + " (Closed)";
					sop.CreditCard.AddCreditCardRow(creditCardNumber, ledgerBalance, creditLimit, productName);
				}				
			}
		}

		private static string PopulateTermLoans(string appId, string channelId, string hostUser, XmlDocument cpiDoc, ArrayList uniqueAcctList,  SOPDataSet sop)
		{
			XmlNodeList termLoanList;
			string returnString = null;

			foreach(string acctUniqueNumberNZBA in uniqueAcctList)
			{
				termLoanList = Balance.ExtractTermLoansFromCPI(cpiDoc, acctUniqueNumberNZBA);

				foreach(XmlNode node in termLoanList)
				{
					string accountNumber;    //bank-branch-stem-suffix in NZBA acct format e.g. 012303900807606
					string paymentNumber;	 //loan payment nubmer e.g 008
					string productName;

					accountNumber = acctUniqueNumberNZBA + GetNodeValue(node, Balance.CPIConstants.AcctSufxNzbaNumb);
					paymentNumber = GetNodeValue(node, Balance.CPIConstants.LoanPaytNumb);
					productName = GetNodeValue(node, Balance.CPIConstants.ProdDescription);
					
					string result = AddTermLoan(appId, channelId, hostUser, accountNumber, paymentNumber, productName, sop);
					if (result != Constants.SUCCESS)
						returnString += result;  //If error occurs, do not quit but accumulate errors to be logged.
				}
			}

			if (returnString != null)
				return returnString;   //return all accumulated errors
			else
				return Constants.SUCCESS;
		}
	

		private static string PopulateAccountsFromCPID(string appId, string channelId, string hostUser, XmlDocument cpiDoc, ArrayList uniqueAcctList,  SOPDataSet sop)
		{
			string returnString = null;
			XmlNodeList cpidAcctList;
			
			foreach(string acctUniqueNumberNZBA in uniqueAcctList)
			{
				cpidAcctList = Balance.ExtractCPIDsFromCPI(cpiDoc, acctUniqueNumberNZBA);

				foreach(XmlNode node in cpidAcctList)
				{
					string nzbaAccountNumber;    //bank-branch-stem-suffix in NZBA acct format
					decimal balance;
					decimal limit;
					string accountDisplayName;
					int productCode;
					string productName;
					int sopAssetTypeNumb;

					nzbaAccountNumber = acctUniqueNumberNZBA + GetNodeValue(node, Balance.CPIConstants.AcctSufxNzbaNumb);
					balance = GetNodeValue(node, Balance.CPIConstants.AcctLedgerBalAmt, decimal.Zero)/100;
					accountDisplayName = GetNodeValue(node, Balance.CPIConstants.AcctPersonalisedName);
					productCode = GetNodeValue(node, Balance.CPIConstants.ProdNumb, 0);
					
					limit = GetNodeValue(node, Balance.CPIConstants.AcctOvdtLimitFormalAmt, decimal.Zero)/100;
				
					//if personalised name not set, display account number formmated in 2 4 7 2 format
					if (accountDisplayName == null || accountDisplayName == string.Empty)
						accountDisplayName = FormatNZBAAcctNumberToDisplayFormat(nzbaAccountNumber);

					if (limit > decimal.Zero)
					{
						if (IsRevolvingCreditProduct(productCode))
						{
							productName = GetNodeValue(node, Balance.CPIConstants.ProdDescription);

							if (productCode == RefDB.ProductCode.OrbitFastTrackHomeLoan)
							{
								//Orbit FastTrack Home Loan 
								string paymentnumber = "0";						
								string result = AddTermLoanOrbitFastTrackLoan(appId, channelId, hostUser, nzbaAccountNumber, paymentnumber, false, productName, limit, sop);
								if (result != Constants.SUCCESS)
									returnString += result;
							}
							else
							{
								//Other revolving credit products such as Orbit Home Loan, Flexible Finacnce Facility 
								//balance * -1 because for liability balance in DR is the normal case
								sop.RevolvingCreditLoan.AddRevolvingCreditLoanRow(nzbaAccountNumber, -1 * balance,limit, productName);													
							}
						
						}
						else 
						{
							//overdraft - balance * -1 because for liability  in DR is the normal case
							sop.Overdraft.AddOverdraftRow(accountDisplayName,nzbaAccountNumber, -1 * balance, limit);
						}
					}
					else 
					{
						//normal accounts
						sopAssetTypeNumb = RefDB.SopAssetType.PersonalAndBusinessAccount; //TODO confirm
						sop.Account.AddAccountRow(accountDisplayName, nzbaAccountNumber, balance, sopAssetTypeNumb);
					}
				}
			}

			if (returnString != null)
				return returnString;   //return all accumulated errors
			else
				return Constants.SUCCESS;
		}


		private static void PopulateInvestments(XmlDocument cpiDoc, ArrayList uniqueAcctList,  SOPDataSet sop)
		{
			XmlNodeList cpidAcctList;
			
			foreach(string acctUniqueNumberNZBA in uniqueAcctList)
			{
				cpidAcctList = Balance.ExtractCPIIsFromCPI(cpiDoc, acctUniqueNumberNZBA);

				foreach(XmlNode node in cpidAcctList)
				{
					string nzbaAccountNumber;    //bank-branch-stem-suffix in NZBA acct format
					decimal balance;
					string accountDisplayName;
					int sopAssetTypeNumb;

					accountDisplayName = GetNodeValue(node, Balance.CPIConstants.AcctPersonalisedName);
					nzbaAccountNumber = acctUniqueNumberNZBA + GetNodeValue(node, Balance.CPIConstants.AcctSufxNzbaNumb);
					balance = GetNodeValue(node, Balance.CPIConstants.AcctLedgerBalAmt, Decimal.Zero)/100;
					if (accountDisplayName == null || accountDisplayName == string.Empty)
						accountDisplayName = FormatNZBAAcctNumberToDisplayFormat(nzbaAccountNumber);					
					sopAssetTypeNumb = RefDB.SopAssetType.TermInvestment;  //TODO confirm
					
					sop.Account.AddAccountRow(accountDisplayName, nzbaAccountNumber, balance, sopAssetTypeNumb);
					
				}
			}
		}


		private static string GetUniqueAccountsOwnedByCust(string appId, string channelId, string hostUserName, string bankNumber, string customerNumber, out ArrayList acctList)
		{
			acctList = new ArrayList();

			//Get unqiue account number (Bank-Branch-Stem) for this customer
			//According to Technical Design - Prepop, when calling GetUniqueNumbers
			//set both optAllUniqueNumbers and optEnquireInvestment to true.
			string outputXml;
			string result = Balance.GetUniqueNumbers(appId, channelId, hostUserName, int.Parse(bankNumber),customerNumber, true, true, out outputXml);  

			if (result != Constants.SUCCESS)
				return result;

			if (outputXml != null && outputXml != string.Empty)
			{
				XmlDocument acctDoc = new XmlDocument();
				acctDoc.LoadXml(outputXml);

				foreach(XmlNode uniqueAcctNode in acctDoc.SelectNodes("//UniqueNumber"))
				{
					string uniqueAcct = uniqueAcctNode.Attributes[CUQConstants.AcctUniqueNumber].InnerText;
					string uniqueAcctNZBA = FormatAcctUniqueNumber(uniqueAcct);
					acctList.Add(uniqueAcctNZBA);
				}
			}
			return Constants.SUCCESS;
		}

		private static string AddTermLoan(string appId, string channelId, string hostUser, string accountNumber, string paymentNumber, string productName, SOPDataSet sop)
		{
			return AddTermLoanOrbitFastTrackLoan(appId, channelId, hostUser, accountNumber, paymentNumber, true,  productName,  0,  sop);
		}

		private static string AddTermLoanOrbitFastTrackLoan(string appId, string channelId, string hostUser, string accountNumber, string paymentNumber, bool isTermLoan, string productName, decimal limitAmt, SOPDataSet sop)
		{
			//Get loan details
			string outputXml;
			string result = Constants.SUCCESS;
			result = Balance.GetAutoPaymentLoanAuthorityDetail(appId, channelId, hostUser, accountNumber, paymentNumber, out outputXml);

			if (result != Constants.SUCCESS)
				return result;

			XmlDocument loanDetailsDoc = new XmlDocument();
			loanDetailsDoc.LoadXml(outputXml);
			XmlNode loanDetailsNode = loanDetailsDoc.SelectSingleNode("//Section_424D");

			if (loanDetailsNode!= null)
			{	
				string fullAcctNumber;   //bank-branch-stem-suffix-paymentNumb in NZBA acct format 
				decimal outstandingBalanceAmt;
				decimal originalLoanAmt;
				decimal loanAmt;
				decimal paymentAmt;
				string paymentFrequency;					
				bool isInProgress;
				bool isMortgageFlag;
				int repaymentFrequencyNumb;   //RPMTFreqNumb, LRPF_N
				int autoPaymentFrequencyNumb;  //APFQ_N - Need to translate RPMTFreqNumb to APFQ_N to pass to middleware
				int loanTypeNumb;   //LNTP_N
				int sopOutgoingTypeNumb;  //SPOT_N
				
				fullAcctNumber = accountNumber + paymentNumber;
				//outstanding balance is PrincOwedLoanAmt * -1 because liability is expected to be in DR.
				outstandingBalanceAmt =  -1 * GetNodeValue(loanDetailsNode,LoanDetailsConstants.PrincOwedLoanAmt,decimal.Zero)/100;
				originalLoanAmt = GetNodeValue(loanDetailsNode,LoanDetailsConstants.GrossLoanAmt,decimal.Zero)/100;
						
				paymentAmt =  GetNodeValue(loanDetailsNode,LoanDetailsConstants.PaytDueAmt,decimal.Zero)/100;
				paymentFrequency = GetNodeValue(loanDetailsNode, LoanDetailsConstants.RpmtFreqDesc);
				repaymentFrequencyNumb = GetNodeValue(loanDetailsNode, LoanDetailsConstants.RpmtFreqNumb,0); 
				loanTypeNumb = GetNodeValue(loanDetailsNode, LoanDetailsConstants.LoanTypeNumb, 0);

				autoPaymentFrequencyNumb = GetAutoPaytFrequencyForLoanRepaymentFrequency(repaymentFrequencyNumb);

				if (loanDetailsNode.SelectSingleNode(LoanDetailsConstants.PrincOwedLoanAmt) == null )
				{
					//loan is in progress if node PrincOwedLoanAmt does not exist
					//don't care about paymentAmt in this case (confirmed with Rick)
					loanAmt = originalLoanAmt;
					paymentAmt = 0;
					isInProgress = true; 
				}
				else
				{
					loanAmt = outstandingBalanceAmt;
					isInProgress = false;
				}
				
				if (isTermLoan)
				{
					sopOutgoingTypeNumb = GetSopOutgoingTypeNumbForLoanType(loanTypeNumb);
					isMortgageFlag = IsMortgageCheck(loanTypeNumb);
					sop.TermLoan.AddTermLoanRow(fullAcctNumber,loanAmt, paymentFrequency, autoPaymentFrequencyNumb, paymentAmt, isInProgress, isMortgageFlag, sopOutgoingTypeNumb, productName);
				}
				else
					sop.OrbitFastTrackLoan.AddOrbitFastTrackLoanRow(fullAcctNumber,loanAmt, paymentFrequency, autoPaymentFrequencyNumb, paymentAmt, isInProgress, limitAmt, productName);
			}
			return Constants.SUCCESS;
		}

		/// <summary>
		/// Except for Personal Loan, all other loan type is classed as Mortgage.
		/// </summary>
		/// <param name="loanType"></param>
		/// <returns></returns>
		private static bool IsMortgageCheck(int loanType)
		{
			if (loanType == RefDB.LoanTypeSSS.PersonalLoan)
				return false;
			else
				return true;
		}

		private static bool IsRevolvingCreditProduct(int productCode)
		{
			switch (productCode)
			{
				case RefDB.ProductCode.OrbitFastTrackHomeLoan:
				case RefDB.ProductCode.OrbitHomeLoan:
				case RefDB.ProductCode.FlexibleFinanceFacility:
				case RefDB.ProductCode.OrbitHomeLoanBusn:
				case RefDB.ProductCode.HomePlus:
					return true;
				default:
					return false;
			}
		}



		private static string FormatAcctUniqueNumber(string acctUniqueNumber)
		{
			ASB.Utility.Account.AccountNumber acct = new ASB.Utility.Account.AccountNumber(acctUniqueNumber);
			return acct.NZBAAccountNumberNoSuffix;
		}


		/// <summary>
		/// Format account in a 2 4 7 2 format
		/// </summary>
		/// <param name="nzbaAccountNumber"></param>
		/// <returns></returns>
		private static string FormatNZBAAcctNumberToDisplayFormat(string nzbaAccountNumber)
		{
			return string.Format ("{0} {1} {2} {3}", 
				nzbaAccountNumber.Substring(1,2),
				nzbaAccountNumber.Substring(3,4),
				nzbaAccountNumber.Substring(8,7),
				nzbaAccountNumber.Substring(17,2));
			
		}

		private static string GetNodeValue(XmlNode node, string elementName)
		{
			return GetNodeValue(node, elementName, null);
		}

		private static string GetNodeValue(XmlNode node, string elementName, string defaultValue)
		{
			XmlNode target = node.SelectSingleNode(elementName);
			if (target != null)
				return target.InnerText;
			else
				return defaultValue;
		}

		private static decimal GetNodeValue(XmlNode node, string elementName, decimal defaultValue)
		{
			string nodeValue = GetNodeValue(node, elementName, null);
			return ConvertToDecimal(nodeValue, defaultValue);
		}

		private static int GetNodeValue(XmlNode node, string elementName, int defaultValue)
		{
			string nodeValue = GetNodeValue(node, elementName, null);
			return ConvertToInt(nodeValue, defaultValue);
		}
		

		private static decimal ConvertToDecimal(string input, decimal defaultValue)
		{
			if (input != null && input != string.Empty)
				return decimal.Parse(input);
			else
				return defaultValue;
		}


		private static int ConvertToInt(string input, int defaultValue)
		{
			if (input != null && input != string.Empty)
				return int.Parse(input);
			else
				return defaultValue;
		}

		#region RefDB translations

		/// <summary>
		/// Translate RefDB Loan Type to Sop Outgoing Type
		/// </summary>
		/// <param name="loanTypeNumb">RefDB Loan Type (LNTP_N) returns from 424D GetAutoPaymentLoanAuthorityDetail call 
		/// in LoanTypeNumb node.</param>
		/// <returns>RefDB SPOT_N representing a Sop outgoing type.</returns>
		private static int GetSopOutgoingTypeNumbForLoanType(int loanTypeNumb)
		{
			switch(loanTypeNumb)
			{
				case RefDB.LoanTypeSSS.PrimeHousing:
					return RefDB.SopOutgoingType.Loan;
				case RefDB.LoanTypeSSS.PersonalLoan:
					return RefDB.SopOutgoingType.PersonalLoan;
				case RefDB.LoanTypeSSS.Orbit:
					return RefDB.SopOutgoingType.RevolvingCredit;
				default:  //everything else
					return RefDB.SopOutgoingType.Other;
			}
		}

		

		/// <summary>
		/// Translate RefDB Loan Repayment Frequency to Automatic Payment Frequency
		/// </summary>
		/// <param name="loanTypeNumb">RefDB Loan Repayment Frequency (LRPF_N) returns from 424D GetAutoPaymentLoanAuthorityDetail call 
		/// in RpmtFreqNumb node.</param>
		/// <returns>RefDB APFQ_N representing automatic payment frequency.</returns>
		private static int GetAutoPaytFrequencyForLoanRepaymentFrequency(int loanRepaymentFrequency)
		{
			switch(loanRepaymentFrequency)
			{
				case RefDB.LoanRepaymentFrequency.Monthly:
					return RefDB.AutomaticPaytFrequency.Monthly;
				case RefDB.LoanRepaymentFrequency.Fortnightly:
					return RefDB.AutomaticPaytFrequency.Fortnightly;
				case RefDB.LoanRepaymentFrequency.Quarterly:
					return RefDB.AutomaticPaytFrequency.Quarterly;
				case RefDB.LoanRepaymentFrequency.SixMonthly:
					return RefDB.AutomaticPaytFrequency.SixMonthly;
				case RefDB.LoanRepaymentFrequency.Annually:
					return RefDB.AutomaticPaytFrequency.Yearly;
				default:
					return 0;
			}
		}
		#endregion

		
		#region Constants

		/// <summary>
		/// Xml Node name as returned from ICustomer_2009_3.GetUniqueNumbers - Get Unique Account Numbers owned by the customer call
		/// </summary>
		private class CUQConstants
		{
			public const string AcctUniqueNumber = "AcctUniqueNumber";
		}

		/// <summary>
		/// Xml Node name as returned from IPayment_2005_2.GetAutoPaymentLoanAuthorityDetail call - Get Loan Details call
		/// </summary>
		private class LoanDetailsConstants
		{
			public const string PrincOwedLoanAmt = "PrincOwedLoanAmt";  //outstanding loan amount
			public const string PaytDueAmt = "PaytDueAmt";              //payment due amount
			public const string GrossLoanAmt = "GrossLoanAmt";          //original loan amount
			public const string RpmtFreqDesc = "RpmtFreqDesc";			//payment frequency description, LRPF_X
			public const string RpmtFreqNumb = "RpmtFreqNumb";  		//payment frequency RItem Numb, LRPF_N
			public const string LoanTypeNumb = "LoanTypeNumb";          //Loan Type Numb LNTP  //TODO confirm
		}

		
		#endregion

	}
}
