using System;
using System.Xml;
using System.Xml.Serialization;
using ASB.CBO.Utility;

namespace ASBBank.FNC.BP.Balance
{
	#region CurrentNetcodeFeeDeductionAccount

	[Serializable]
	[XmlRoot("security")]	
	public class CurrentNetcodeFeeDeductionAccount 
	{
		#region Properties

		private string _typeNumber;

		[XmlElement("typeNumb")]
		public string TypeNumber
		{
			get{return _typeNumber;}
			set{_typeNumber = value;}
		}
	
		private string _typeDesc;
		
		[XmlElement("typeDesc")]
		public string TypeDescription
		{
			get{return _typeDesc;}
			set{_typeDesc = value;}
		}

		private int _limit;
		
		[XmlElement("limit")]
		public int Limit
		{
			get{return _limit;}
			set{_limit=value;}
		}

		private string _reference;
		
		[XmlElement("reference")]
		public string Reference
		{
			get{return _reference;}
			set{_reference = value;}
		}

		private bool _enabled;
		
		[XmlElement("enabled")]
		public string SerializeEnabled
		{
			get{return _enabled.ToString();}
			set
			{
				if(value != null && value.Equals("Y"))
				{
					_enabled=true;
				}
			}
		}
		
		[XmlIgnore()]	
		public bool NetCodeEnabled
		{
			get{return _enabled;}
			set{_enabled=value;}
		}

		private string _feeAccount;
		
		[XmlElement("feeAccount")]
		public string FeeAccount
		{
			get{return _feeAccount;}
			set{_feeAccount = value;}
		}

		private bool _feeExempt;
		
		[XmlElement("feeExempt")]
		public string SerializeFeeExempt
		{
			get{return _feeExempt.ToString();}
			set
			{
				if(value != null && value.Equals("Y"))
				{
					_feeExempt=true;
				}
			}
		}
		
		[XmlIgnore()]	
		public bool FeeExempt
		{
			get{return _feeExempt;}
			set{_feeExempt=value;}
		}

		private string _personalisedName;
		
		[XmlIgnore()]
		public string PersonalisedName
		{
			get
			{
				return _personalisedName;
			}
			set
			{
				_personalisedName = value;
			}
		}

		private string _accessNumber;
		
		[XmlIgnore()]
		public string AccessNumber
		{
			get
			{
				return _accessNumber;	
			}
			set
			{
				_accessNumber = value;
			}
		}

		private string _productDescription;
		
		[XmlIgnore()]
		public string ProductDescription
		{
			get
			{
				return _productDescription;
			}
			set
			{
				_productDescription = value;
			}
		}
		
		[XmlIgnore()]
		private bool _closed = false;

		public bool Closed
		{
			get
			{
				return _closed;
			}
			set
			{
				_closed = value;
			}
		}

		#endregion

		public CurrentNetcodeFeeDeductionAccount()
		{
		}

		public static CurrentNetcodeFeeDeductionAccount Create(string xml)
		{
			return (CurrentNetcodeFeeDeductionAccount)XmlHelper.Inflate(xml, typeof(CurrentNetcodeFeeDeductionAccount));
		}

		public bool IsFeeAccountSpecified()
		{
			if(_feeAccount==null || _feeAccount.Trim().Equals(""))
			{
				return false;
			}
			return true;
		}

		public bool HasPersonalisedName()
		{
			if(_personalisedName==null || _personalisedName.Trim().Equals(""))
			{
				return false;
			}
			return true;
		}
	}
	
	#endregion

	#region NewDefaultNetcodeFeeDeductionAccountBase
	
	[Serializable]
	public abstract class NewDefaultNetcodeFeeDeductionAccountBase
	{
		private string _feeAccount;

		public string FeeAccount
		{
			get{return _feeAccount;}
			set{_feeAccount=value;}
		}
	}

	#endregion

	#region NewDefaultNetcodeFeeDeductionAccount

	[Serializable]
	public class NewDefaultNetcodeFeeDeductionAccount : NewDefaultNetcodeFeeDeductionAccountBase
	{
		private string _personalisedName;

		public string PersonalisedName
		{
			get{return _personalisedName;}
			set{_personalisedName = value;}
		}

		private bool _hasPersonalisedName;

		public bool HasPersonalisedName
		{
			get{return _hasPersonalisedName;}
			set{_hasPersonalisedName = value;}
		}

		public NewDefaultNetcodeFeeDeductionAccount(string feeAccount, string personalisedName)
		{
			base.FeeAccount = feeAccount;
			_personalisedName = personalisedName;
		}
	}

	#endregion

	#region NewNetDirectNetcodeFeeDeductionAccount

	[Serializable]
	public class NewNetDirectNetcodeFeeDeductionAccount : NewDefaultNetcodeFeeDeductionAccountBase
	{
		private string _accessNumber;

		public string AccessNumber
		{
			get{return _accessNumber;}
			set{_accessNumber = value;}
		}

		private string _productDescription;

		public string ProductDescription
		{
			get{return _productDescription;}
			set{_productDescription = value;}
		}

		public NewNetDirectNetcodeFeeDeductionAccount(string feeAccount, string accessNumber, string productDesciption)
		{
			base.FeeAccount = feeAccount;
			_accessNumber = accessNumber;
			_productDescription = productDesciption;
		}
	}

	#endregion
	
}
