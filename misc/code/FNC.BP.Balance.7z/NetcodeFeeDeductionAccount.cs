using System;
using System.EnterpriseServices;
using ASB.Utility.Common;
using System.Xml;
using System.Xml.XPath;

namespace ASBBank.FNC.BP.Balance
{
	/// <summary>
	/// Summary description for NetcodeFeeDeduction.
	/// </summary>
	public class NetcodeFeeDeductionAccount
	{

		public NetcodeFeeDeductionAccount()
		{
		}

		public static string GetNetCodeFeeDeductionAccount(string appID, string channelId, string hostUserName, 
			int customerBankNumber, int customerNumber, int productNumber, int securityType, 
			out CurrentNetcodeFeeDeductionAccount currentAccount)
		{
			string sResult = "";
			string sResultXML = "";
			ASB.BC.Customer.IAuthorisation_2006_2 oAuthorisation = null;

			currentAccount = null;
	
			try
			{
				oAuthorisation = new ASB.BC.Customer.Authorisation();
				sResult = oAuthorisation.GetSecurityHistory(appID, channelId, hostUserName, customerBankNumber, customerNumber,
							productNumber,securityType, out sResultXML);
				if (sResult == Constants.SUCCESS)
				{
					currentAccount = CreateCurrentNetcodeFeeDeductionAccountObject(sResultXML);
				}
			}
			finally
			{
				if(oAuthorisation!=null)
				{
					ServicedComponent.DisposeObject((ServicedComponent)oAuthorisation);
				}
			}	

			return sResult;
		}

		public static string SetNetCodeFeeDeductionAccount(string appID, string channelId, string hostUserName, 
			string personnelName, int branchNumber, int cashNumber, int customerBankNumber, int customerNumber, 
			int productNumber, int securityType, double securityAmount, string ncReference, bool ncRegistered,
			int ncType, string feeAccountNZBA, bool feeExempt)
		{			
			string sResultXML = "";

			ASB.BC.Customer.IAuthorisation_2006_2 oAuthorisation = null;

			try
			{
				oAuthorisation = new ASB.BC.Customer.Authorisation();
				
				return oAuthorisation.SaveSecurityDetails(appID, channelId, hostUserName, 
					personnelName, branchNumber, cashNumber, customerBankNumber, customerNumber, 
					productNumber, securityType, securityAmount, ncReference, ncRegistered,
					ncType, feeAccountNZBA, feeExempt, out sResultXML);
			}
			finally
			{
				if(oAuthorisation!=null)
				{
					ServicedComponent.DisposeObject((ServicedComponent)oAuthorisation);
				}
			}			
		}
	
		private static CurrentNetcodeFeeDeductionAccount CreateCurrentNetcodeFeeDeductionAccountObject(string xmlString)
		{
			CurrentNetcodeFeeDeductionAccount currentAccount = new CurrentNetcodeFeeDeductionAccount();

			XmlDocument oDoc = new XmlDocument();			
			oDoc.LoadXml(xmlString);
			XmlNode securityNode = oDoc.SelectSingleNode("//security");			
						
			if(securityNode != null)
			{				
				currentAccount = CurrentNetcodeFeeDeductionAccount.Create(securityNode.OuterXml);
			}

			return currentAccount;
		}		
	}
}
