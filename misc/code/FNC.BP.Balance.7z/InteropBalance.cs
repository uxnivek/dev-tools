﻿using ASB.Utility.Common;
using System.Runtime.InteropServices;

namespace ASBBank.FNC.BP.Balance
{
    [Guid("428072D4-7DA2-40B9-B8E5-C6CA4C7B5D5B")]
    public interface IInteropBalance
    {
        string GetProductsByCustomer(string sSessionGUID, string sChannelId, string sBankNumber, string sCustomerNumber, out string sxml);
    }

    [Guid("CB37EC93-F9FC-41C2-AFCF-C30D98961293")]
    public class InteropBalance : IInteropBalance
    {
        public string GetProductsByCustomer(string sSessionGUID, string sChannelId, string sBankNumber, string sCustomerNumber, out string sxml)
        {
            string sResult = string.Empty;
            sxml = null;
           
            Balance.GetProductsByCustomer(sSessionGUID, sChannelId, sChannelId, sBankNumber, sCustomerNumber, "", out  sxml);
            sResult = Constants.SUCCESS;

            return sResult;
        }
    }
}
