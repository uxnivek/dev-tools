using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using ASB.ApplicationServices.CBO.AddressService;
using ASB.BC.Customer;
using ASB.CBO.Utility;
using ASB.Utility.Common;
using System.Collections;
using System.EnterpriseServices;
using System.Xml;
using ASB.CBO.DA;
using ASBBank.FNC.BP.Statement;
using ASB.Mapping.SerializationMapper;
using AddressService = ASB.CBO.Middleware.AddressService;
using CreditCard = ASB.ApplicationServices.CBO.AddressService.CreditCard;
using ProductSummaryService = ASB.CBO.Middleware.ProductSummaryService;
using Severity = ASB.ApplicationServices.CBO.ProductSummaryService.Severity;

namespace ASBBank.FNC.BP.Balance
{
	public class Balance
	{
		//TODO consider moving these to new constant file FNC.BP.Common.RefDBConstants.
        //HD0000001578955 - True Rewards Application for Low Interest Master Card and Visa Business . 
        //Through middleware the product code  for Low Interest Master Card is 2516 and not 02516 
		private const string LI_MASTERCARD_PRODUCT_CODE = "2516";
        private const string VISABUSINESS_PRODUCT_CODE = "1169";
		private const int ASBPROD_ATTR_PINSELECT = 64;

		private const string PROD_FCA_TREASURY_TERM_DEP = "3930";
		private const string PROD_FCA_ASBSEC_CALL_DEP = "3922";
		private const string PROD_FCA_ASBSEC_TERM_DEP = "3949";
		private const string PROD_ATTRIBUTE_PERSONALISATION = "48939";
        private const int MAX_RECORS_RETURNED = 10000;
	    private const int NETDIRECT_BANK_NUMBER = 21;

		// The following are some of the products which are to be excluded for fee accounts
		private static readonly int[] prodGroup = {174,342,617,625,633,641,1089,1097,3615,2073, 4511};

	    public Balance()
		{				
			
		}
		internal static string GetProductsByCustomer(string sSessionGUID, string sAppId, string sChannelId,
			string sBankNumber, string sCustomerNumber, string sHostUsername, out string sxml)
		{
			return GetProductsByCustomer(sSessionGUID, sAppId, sChannelId, sBankNumber, sCustomerNumber,
				sHostUsername, out sxml, true);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="bFetch">If true (default) then will fetch from the cache if nothing found.</param>
		/// <returns></returns>
		internal static string GetProductsByCustomer(string sSessionGUID, string sAppId, string sChannelId,
			string sBankNumber, string sCustomerNumber, string sHostUsername, out string sxml, bool bFetch)
		{
			string sFac = string.Empty;
			string sResult = string.Empty;
			sxml = null;

			if (sSessionGUID != null && sSessionGUID != string.Empty)
			{
				//Attempt to read from cache.
				FNCDASessionCache.SessionCache session = new FNCDASessionCache.SessionCacheClass();
				string sSessionId = string.Empty;
				object dat1 = null;
				object dat2 = null;
				object dat3 = null;

				//8 = FNCCIT_BALANCES == 1 = XML result.
				int iResult = session.GetSessionAndCache(sSessionGUID, 8, "1", ref sBankNumber, ref sCustomerNumber,
					ref sFac, ref sSessionId, ref dat1, ref dat2, ref dat3);
				
				if (dat1 != null)
				{
					sxml = System.Text.Encoding.Unicode.GetString((byte[])dat1);
					sResult = Constants.SUCCESS;
					session = null;
				}
			}

            if (bFetch && string.IsNullOrEmpty(sxml))
			{
                var service = new ProductSummaryService();
                var customer = Convert.ToInt32(sCustomerNumber);
                var bankNumber = Convert.ToInt32(sBankNumber);
				if (sChannelId == "NETDIRECT")
				{
				    bankNumber = NETDIRECT_BANK_NUMBER;
				}
                var response = service.GetProductSummary(customer, bankNumber, sChannelId, sFac);
                if (response.ErrorInfo != null)
                {
                    int iLogId;
                    foreach (var errorInfo in response.ErrorInfo.Where(errorInfo => errorInfo.Severity != Severity.Success))
                    {
                        Logging.ErrorLog(errorInfo.Code, errorInfo.Description, "Middleware Return: called from FNC.BP.Balance- ProductSummaryMiddleware call- GetProductsByCustomer", Environment.MachineName, sFac, errorInfo.Severity.ToString(),
                                            sSessionGUID, string.Empty, errorInfo.Description, errorInfo.ProductSystemId.ToString(CultureInfo.InvariantCulture), errorInfo.Code,
                                            string.Empty, errorInfo.Severity.ToString(), sSessionGUID, sChannelId, out iLogId);
                    }
                }

                sxml = ProductSummaryHelper.SerializedXML(response);
				sResult = Constants.SUCCESS;
				
				if (sSessionGUID != null && sSessionGUID != string.Empty)
				{
					//Save the result to the session.
					FNCDASessionCache.SessionCache session = new FNCDASessionCache.SessionCacheClass();
					object dat1 = System.Text.Encoding.Unicode.GetBytes(sxml); 
					object dat2 = null;
					object dat3 = null;
					session.AddByGUID(sSessionGUID, 8, "1", dat1, dat2, dat3);
					session = null;
				}

			}

			return sResult;
		}
		

		public static string GetDebitCardStemNumber(string sSessionGUID, string sAppID, string sChannelID, 
			string sCustomerNumber, string sDebitCardNumber)
		{
			string sResult;
			string sXML;
			string sDebitCardStemNumber = string.Empty;
			XmlDocument oDom = new XmlDocument();
            
			sResult = GetProductsByCustomer(sSessionGUID, sAppID,sChannelID, "12", sCustomerNumber, "", out sXML);

			if (sResult == Constants.SUCCESS)
			{
				oDom.LoadXml(sXML);
				if(oDom.SelectSingleNode("/TMResponse/Section_CPIV/CardStatusFlag") == null ||
					oDom.SelectSingleNode("/TMResponse/Section_CPIV/CardStatusFlag").InnerText == "")
					sDebitCardStemNumber = oDom.SelectSingleNode("/TMResponse/Section_CPIV[DebitCardNumb=" + sDebitCardNumber + "]/AcctUniqueNZBANumb").InnerText;
			}
			return sDebitCardStemNumber;			
		}

		public static string GetDebitCards(string sSessionGUID, string sAppID, string sChannelID,
			string sBankNumber, string sCustomerNumber, string sHostUserName, out DataTable dtDebitCards)
		{
			string sResult;
			string sXML;
			DataSet dsData = new DataSet();	
			dtDebitCards = new DataTable("DebitCards");
			dtDebitCards.Columns.Add("AcctUniqueNZBANumb");
			dtDebitCards.Columns.Add("DebitCardNumb");
			dtDebitCards.Columns.Add("CardProductNumb"); 
			dtDebitCards.Columns.Add("CardStatusFlag");
			dtDebitCards.Columns.Add("ExpiryDate");
            dtDebitCards.Columns.Add("ProdDescription");

			sResult = GetProductsByCustomer(sSessionGUID, sAppID,sChannelID, "12", sCustomerNumber, "", out sXML);
			if (sResult == Constants.SUCCESS)
			{
				dsData.ReadXml( new System.IO.StringReader(sXML),XmlReadMode.InferSchema);		
			
				if (dsData.Tables.Contains("Section_CPIV"))
				{
					foreach (DataRow row in dsData.Tables["Section_CPIV"].Rows)
					{
						if(row["CardStatusFlag"] == null || row["CardStatusFlag"].ToString() == "")
						{	
							FNC.BP.Balance.FeeAccountDetail[] feeAccountDetails = null;	
							GetFeeAccounts(sSessionGUID, sAppID, sChannelID, sBankNumber, sCustomerNumber, 
								sHostUserName, row["AcctUniqueNZBANumb"].ToString(), 
								out feeAccountDetails, true);
							if (feeAccountDetails != null && feeAccountDetails.Length != 0)
							{
								dtDebitCards.Rows.Add(new object[] {row["AcctUniqueNZBANumb"],
																	   row["DebitCardNumb"],
																	   row["CardProductNumb"],
																	   row["CardStatusFlag"], 
																	   row["ExpiryDate"],
                                                                       row["ProdDescription"] });
							}
						}
					}
				}
			}
			return sResult;

		}

		public static string GetVisaDebitCardStems(string sSessionGUID, string sAppID, string sChannelID,
			string sBankNumber, string sCustomerNumber, string sHostUserName, out ArrayList arrVisaDebit)
		{
			string sResult;
			string sXML;
			arrVisaDebit = new ArrayList();

			DataSet dsData = new DataSet();	

			sResult = GetProductsByCustomer(sSessionGUID, sAppID,sChannelID, "12", sCustomerNumber, "", out sXML);
			if (sResult == Constants.SUCCESS)
			{
				dsData.ReadXml( new System.IO.StringReader(sXML),XmlReadMode.InferSchema);		
			
				if (dsData.Tables.Contains("Section_CPIV"))
				{
					foreach (DataRow row in dsData.Tables["Section_CPIV"].Rows)
					{
						if(Int64.Parse(row["CardProductNumb"].ToString()) == 4431)
						{	
							string stem = GetDebitCardStemNumber(sSessionGUID, sAppID, sChannelID, sCustomerNumber, row["DebitCardNumb"].ToString());

							arrVisaDebit.Add(stem);
						}
					}
				}
			}
			return sResult;
		}

		public static string GetPinSelectableCards(string sSessionGUID, string sAppID, string sChannelID, 
			string sBankNumber, string sCustomerNumber, string sHostUserName, out DataTable dtPinSelectableCards)
		{
			string sResult;
			string sXML;
			DataSet dsData = new DataSet();	
			dtPinSelectableCards = new DataTable("PinSelectableCards");
			dtPinSelectableCards.Columns.Add("CardNumber");
			dtPinSelectableCards.Columns.Add("ProductNumb"); 
			dtPinSelectableCards.Columns.Add("ProdDescription");
			dtPinSelectableCards.Columns.Add("ProdAttributes",System.Type.GetType("System.Int32"));
            dtPinSelectableCards.Columns.Add("IsMobileCard", System.Type.GetType("System.Boolean"));
            dtPinSelectableCards.Columns.Add("IsPayTag", System.Type.GetType("System.Boolean"));
            dtPinSelectableCards.Columns.Add("MobileCardType");

			sResult = GetProductsByCustomer(sSessionGUID, sAppID,sChannelID, "12", sCustomerNumber, "", out sXML);
			if (sResult == Constants.SUCCESS)
			{
				dsData.ReadXml( new System.IO.StringReader(sXML),XmlReadMode.InferSchema);		
			
				if (dsData.Tables.Contains("Section_CPIC"))
				{
					foreach (DataRow row in dsData.Tables["Section_CPIC"].Rows)
					{
						int iProdAttribute = int.Parse(row["ProdAttributes"].ToString());
						bool bShowCardAccount = (row["AccountStatus"].ToString().Length > 0) ? false: true;						
						if((iProdAttribute & ASBPROD_ATTR_PINSELECT) == ASBPROD_ATTR_PINSELECT && bShowCardAccount)
						{
							dtPinSelectableCards.Rows.Add(new object[] {row["CrCardNumb"],
																		   row["ProdNumb"],
																		   row["ProdDescription"],
																		   row["ProdAttributes"],false});
						}
					}
				}
				if (dsData.Tables.Contains("Section_CPIV")) // VISA Debit
				{
					foreach (DataRow row in dsData.Tables["Section_CPIV"].Rows)
					{
						int iProdAttribute = int.Parse(row["ProdAttributes"].ToString());
						if((iProdAttribute & ASBPROD_ATTR_PINSELECT) == ASBPROD_ATTR_PINSELECT)
						{
							//Exclude cards that have any type of Hold.
							if(row["CardStatusFlag"] == null || row["CardStatusFlag"].ToString() == "")
							{

								FNC.BP.Balance.FeeAccountDetail[] feeAccountDetails = null;	
								GetFeeAccounts(sSessionGUID, sAppID, sChannelID, sBankNumber, sCustomerNumber, 
									sHostUserName, row["AcctUniqueNZBANumb"].ToString(), 
									out feeAccountDetails, true);
								if (feeAccountDetails != null && feeAccountDetails.Length != 0)
								{
									dtPinSelectableCards.Rows.Add(new object[] {row["DebitCardNumb"],
																				   row["CardProductNumb"],
																				   row["ProdDescription"], 
																				   row["ProdAttributes"], false});
								}
							}
						}
					}
				}
			}
			return sResult;

		}

		public static string GetAccountStems(string sSessionGUID, string sAppID, string sChannelID, string sCustomerNumber, out DataTable dtStems)
		{
			return GetAccountStems(sSessionGUID, sAppID, sChannelID, sCustomerNumber, out dtStems, false);
		}

		/// <summary>
		/// Gets all of a customers account stems and the account names for those stems.
		/// </summary>	
		/// <param name="dtStems">
		/// TableName: AccountStem
		/// ColumnNames: StemNumber, AccountName
		/// </param>
		/// <param name="includeCCAccounts">If true, include credit card accounts for the customer</param> 
		public static string GetAccountStems(string sSessionGUID, string sAppID, string sChannelID, string sCustomerNumber, out DataTable dtStems, bool includeCCAccounts)
		{
			string sxml;
			string sResult;
			DataSet dsData = new DataSet();	
			dtStems = new DataTable("AccountStem");
			dtStems.Columns.Add("StemNumber");
			dtStems.Columns.Add("AccountName");
			dtStems.Columns.Add("TwoToSign",typeof(int)); //TTW 44900 - Indicates if the account is 2ToSign account. Since we are setting
			//this flag at the stem level we need to check if any of the its suffix accounts
			//has multiple signatures required. If yes, then set the flag to true.
			dtStems.Columns.Add("AccountOwnerFlag",typeof(bool)); //indicates if the logged in user is the owner of the accountstem. 			
			dtStems.Columns.Add("CardStatus");
			dtStems.Columns.Add("AccountStatus");
           
			if (includeCCAccounts)
			{
				DataColumn dcCC = new DataColumn("CreditCard",typeof(bool)); //Indicates if the account is a credit card account
				dcCC.DefaultValue = false;
				dtStems.Columns.Add(dcCC);
			}
            
            dtStems.Columns.Add("JointFlag");
            dtStems.Columns.Add("AssociateAccountNumber"); 

		    sResult = GetProductsByCustomer(sSessionGUID, sAppID,sChannelID, "12", sCustomerNumber, "", out sxml);
			if (sResult == Constants.SUCCESS)
			{
				dsData.ReadXml( new System.IO.StringReader(sxml),XmlReadMode.InferSchema);		
			
				if (dsData.Tables.Contains("Section_CPIA"))
				{
					foreach (DataRow row in dsData.Tables["Section_CPIA"].Rows)
					{
						//Build datatable, excluding pago wallet accounts, i.e. bank and branch of '0123456'
						if (row["AcctUniqueNzbaNumb"].ToString().IndexOf("0123456") != 0)
							dtStems.Rows.Add(new object[] {row["AcctUniqueNzbaNumb"],
											row["AcctName"],
											Is2ToSignAccount(row["AcctUniqueNzbaNumb"].ToString(),dsData),
                                            row["IsAccountOwner"],
											null,
											null});
					}
				}
				
				if (includeCCAccounts)
				{
					if (dsData.Tables.Contains("Section_CPIC"))
					{
						foreach (DataRow row in dsData.Tables["Section_CPIC"].Rows)	
						{
							//Build datatable, excluding loyalty cards i.e. starts with '5000512'
							//and exlude closed/cancelled cards with zero balance   
						    bool bShowCardAccount = (row["AccountStatus"].ToString().Length > 0 && (row["CrCardLedgerBalAmt"].ToString() == "0.00" || row["CrCardLedgerBalAmt"].ToString() == "0")) ? false: true;
						    string jointFlag = row["JointFlag"].ToString();
                            string additionalFlag = row["AdditionalFlag"].ToString();
                            if (additionalFlag == "Y")
						        jointFlag = "A";
						    string associateAccountNumber = string.Empty;
                            bool includeloyaltyCards = row["CrCardNumb"].ToString().IndexOf("5000512") != 0;
                            associateAccountNumber = row["AssociateAccountNumber"].ToString();
                            includeloyaltyCards = true;

                            if (includeloyaltyCards && bShowCardAccount)

								dtStems.Rows.Add(new object[] {row["CrCardNumb"],
												row["ProdDescription"],
												0,
												true,												
												row["CardStatus"],
												row["AccountStatus"],
                                                true,
                                                jointFlag,
                                                associateAccountNumber});
						}
					}
				}

			}
			return sResult;
		}

        private static CreditCard[] GetListofCreditCards(string sSessionGUID, string sAppID, string sChannelID, string sCustomerNumber)
        {
            string sxml;
            string sResult;
            var dsData = new DataSet();
            var creditCardNumbers = new List<CreditCard>();
             sResult = GetProductsByCustomer(sSessionGUID, sAppID,sChannelID, "12", sCustomerNumber, "", out sxml);
             if (sResult == Constants.SUCCESS)
             {
                 dsData.ReadXml(new System.IO.StringReader(sxml), XmlReadMode.InferSchema);
                 if (dsData.Tables.Contains("Section_CPIC"))
                 {
                     foreach (DataRow row in dsData.Tables["Section_CPIC"].Rows)
                     {
                             var accountNumber = row["AssociateAccountNumber"].ToString();
                             var creditCard = row["CrCardNumb"].ToString();
                             var creditCardNumber = new CreditCard {AccountNumber = accountNumber, CreditCardNumber = creditCard};
                             var accountStatus = row["AccountStatus"].ToString();
    
                             if(String.IsNullOrEmpty(accountStatus))
                                creditCardNumbers.Add(creditCardNumber);
                        
                     }
                 }
             }
            return creditCardNumbers.ToArray();

        }

	    /// <summary>
		/// Returns if the customer is the owner of the accountstem
		/// </summary>
		/// <param name="sCustomerNumber">Customer Number</param> 
		/// <param name="sJointlyOwnedFlag">Account stem's owner CIF number</param> 
		private static bool IsAccountOwner(string sJointlyOwnedFlag,string sCustomerNumber)
	    {
            if (sJointlyOwnedFlag == "") sJointlyOwnedFlag = "0";
            return (int.Parse(sJointlyOwnedFlag) == int.Parse(sCustomerNumber));
		}

		private static int Is2ToSignAccount(string AcctNumb,DataSet dsData)
		{
						
			if (dsData.Tables.Contains("Section_CPID"))
			{
				DataTable dtCPID = dsData.Tables["Section_CPID"];
				DataRow[] rows = dtCPID.Select("AcctUniqueNzbaNumb LIKE '" + AcctNumb + "*'");
				foreach (DataRow row in rows)
				{
					if (row["SigtReqd"].ToString() != "" && int.Parse(row["SigtReqd"].ToString()) > 1)
						return 1;
				}
			}

			if (dsData.Tables.Contains("Section_CPII"))
			{
				DataTable dtCPII = dsData.Tables["Section_CPII"];
				DataRow[] rows = dtCPII.Select("AcctUniqueNzbaNumb LIKE '" + AcctNumb + "*'");
				foreach (DataRow row in rows)
				{
					if (row["SigtReqd"].ToString() != "" && int.Parse(row["SigtReqd"].ToString()) > 1)
						return 1;
				}
			}

			return 0;
		}


		/// <summary>
		/// Gets the addresses for each account for the user.
		/// </summary>
		/// <param name="accountAddresses">An array of objects containing address information.</param>
		/// <param name="returnAccountsWithoutAddresses">If true and an account does not have an address, then
		/// it will still be returned, however the <see cref="AccountAddress.Address" /> property will be
		/// an empty string.</param>
		public static string GetAccountAddresses(string sSessionGUID, string sAppID, string sChannelID, string sHostUserName, string sCustomerNumber, bool returnAccountsWithoutAddresses, out AccountAddress[] accountAddresses)
		{
			return GetAccountAddresses(sSessionGUID, sAppID, sChannelID, sHostUserName, sCustomerNumber, returnAccountsWithoutAddresses, out accountAddresses,false, "", true, string.Empty);
		}

        public static string GetAccountAddresses(string sSessionGUID, string sAppID, string sChannelID,
                                                 string sHostUserName, string sCustomerNumber,
                                                 bool returnAccountsWithoutAddresses,
                                                 out AccountAddress[] accountAddresses, bool includeCCAccounts,
                                                 string sCustAccessCode, bool includeAdditional, string sBankNumber)
        {
            string ccAddressXml;
            return GetAccountAddresses(sSessionGUID, sAppID, sChannelID, sHostUserName, sCustomerNumber,
                                       returnAccountsWithoutAddresses, out accountAddresses, includeCCAccounts,
                                       sCustAccessCode, includeAdditional, sBankNumber, out ccAddressXml);
        }

		/// <summary>
		/// Gets the addresses for each account for the user.
		/// </summary>
		/// <param name="accountAddresses">An array of objects containing address information.</param>
		/// <param name="returnAccountsWithoutAddresses">If true and an account does not have an address, then
		/// it will still be returned, however the <see cref="AccountAddress.Address" /> property will be
		/// an empty string.</param>
		/// <param name="includeCCAccounts">If true, includes credit card accounts for the user</param> 
        public static string GetAccountAddresses(string sSessionGUID, string sAppID, string sChannelID, string sHostUserName, string sCustomerNumber, bool returnAccountsWithoutAddresses, out AccountAddress[] accountAddresses, bool includeCCAccounts, string sCustAccessCode, bool includeAdditional, string sBankNumber, out string ccAddressXml)
		{
		    ccAddressXml = "";
			DataTable dataTable;
			string result = GetAccountStems(sSessionGUID, sAppID, sChannelID, sCustomerNumber, out dataTable,includeCCAccounts);
			if (result != Constants.SUCCESS) 
			{
				accountAddresses = null;
				return result;
			}
			string sCCAddressesXml= string.Empty;
		    RetrieveAddressResponse retrieveAddressResponse = null;
		    if(includeCCAccounts)
			{
                var creditCards= GetListofCreditCards(sSessionGUID, sAppID, sChannelID, sCustomerNumber);

                var service = new AddressService();
                if (sChannelID == "NETDIRECT")
                {
                    sBankNumber = NETDIRECT_BANK_NUMBER.ToString(CultureInfo.InvariantCulture);
                }

                retrieveAddressResponse = service.RetrieveCreditCardAddress(sBankNumber, creditCards, sCustomerNumber);
                
               
			    
			    if (result != Constants.SUCCESS) 
				{
					accountAddresses = null;
					return result;
				}
			}
			
			ArrayList addresses = new ArrayList();			
			foreach(DataRow row in dataTable.Rows) 
			{
				//TTW50245 -- Future Post 2 to sign accounts
				//Exclude two to sign accounts.  This also applies to Kiwisaver enrolment forms as well.
				bool bIs2ToSign = false;
				bIs2ToSign = int.Parse(row["TwoToSign"].ToString()) < 1 ? false: true;

				//TTW50255 -- Future Post - Exlcude Visa Business accounts from Update Contact details
				//Exclude Business VISA.  This also applies to Kiwisaver enrolment forms as well.
				bool bIsBusinessVisa = (row["StemNumber"].ToString().StartsWith("456491"))? true: false;

                //Exclude additional account
			    bool bIsAdditional = row["JointFlag"].ToString() == "A";

                if (!bIs2ToSign && !bIsBusinessVisa)
                {
                    bool bCCAccount = false;
                    if (includeCCAccounts)
                        bCCAccount = (bool) row["CreditCard"];

                    if ((includeAdditional) || (!includeAdditional && !bIsAdditional))
                    {
                        AccountAddress address = new AccountAddress();
                        address.AccountName = (string) row["AccountName"];
                        address.NzbaAccountNumber = (string) row["StemNumber"];
                        address.AssociateAccountNumber = row["AssociateAccountNumber"].ToString() != string.Empty ? row["AssociateAccountNumber"].ToString() : string.Empty;

                        if (!bCCAccount) //don't get address for credit cards
                        {
                            string address1, address2, address3;
                            result = GetAccountAddress(sAppID, sChannelID, sHostUserName, address.NzbaAccountNumber,
                                                       out address1, out address2, out address3);
                            if (result != Constants.SUCCESS)
                            {
                                accountAddresses = null;
                                return result;
                            }
                            address.Address = ASBBank.FNC.Utility.Utility.Join(", ", address1, address2, address3);
                        }
                        else if (includeCCAccounts && !bIsBusinessVisa)
                        {
                            if (row["AccountStatus"].ToString().Length > 0)
                                address.AccountName = (string)row["AccountName"] + " (Closed)";
                            {
                               
                                GetCreditCardAddress(address, retrieveAddressResponse);  
                                
                            }
                        }
                        if (address.HasAddress || returnAccountsWithoutAddresses || bCCAccount)
                            addresses.Add(address);
                    }
                }
			}

			accountAddresses = (AccountAddress[])addresses.ToArray(typeof(AccountAddress));
			

			return Constants.SUCCESS;
		}

		public static string GetAccountAddress(string sAppID, string sChannelID, string sHostUserName, 
			string sAccountNumber, out string sAddress1, out string sAddress2, out string sAddress3)
		{
			string sResult;
			bool OverseasAddressFlag;

			sResult = GetAccountAddress(sAppID,sChannelID,sHostUserName,sAccountNumber,out sAddress1,
				out sAddress2, out sAddress3, out OverseasAddressFlag);

			return sResult;
		}



		/// <summary>
		/// Gets the address for the account with the given NZBA-formatted account number.  Each output
		/// will be an empty string if no account is stored for the address.
		/// </summary>
		public static string GetAccountAddress(string sAppID, string sChannelID, string sHostUserName, 
			string sAccountNumber, out string sAddress1, out string sAddress2, out string sAddress3, out bool OverseasAddressFlag)
		{

			// note: the middleware call appears to not take an NZBA-number, but rather one with one 
			// less leading zero in the stem.  E.g. NZBA number: "012308600123573" -> "01230860123573"
			string hackedAccountNumber = sAccountNumber.Substring(0, 7) + sAccountNumber.Substring(8);

			string sXml;
			string sResult;
			string[] sAddress;
			sAddress1 = "";
			sAddress2 = "";
			sAddress3 = "";
			OverseasAddressFlag = false;
			DataSet dsData = new DataSet();
			ASB.BC.Account.IAccount_2009_2 oAccount = null;
			
			try
			{
				oAccount = new ASB.BC.Account.Account();
				if(sHostUserName==null)
					sHostUserName = "";
				sResult = oAccount.GetAccountAddress(sAppID, sChannelID, "", sHostUserName,	hackedAccountNumber, out sXml);
				if (sResult == Constants.SUCCESS)
				{
					dsData.ReadXml( new System.IO.StringReader(sXml),XmlReadMode.InferSchema);
					sAddress = dsData.Tables[0].Rows[0]["GroupAccountAddress"].ToString().Split('~');
					for(int i=0;i<sAddress.GetLength(0);i++)
					{
						switch (i)
						{
							case 0:
								sAddress1 = sAddress[0];
								break;
							case 1:
								sAddress2 = sAddress[1];
								break;
							case 2:
								sAddress3 = sAddress[2];
								break;
							default:
								sAddress3 += ", " + sAddress[i];
								break;
						}
						if (((string)(sAddress1 + sAddress2 + sAddress3)).Replace(",","").Trim() == "")
						{
							sAddress1 = "";
							sAddress2 = "";
							sAddress3 = "";
						}
					}
					string OverseasAddress = dsData.Tables[0].Rows[0]["GroupOverseasAddressFlag"].ToString();
					OverseasAddressFlag = OverseasAddress.ToUpper() == "Y" ? true : false;			
			
				}
				return sResult;
			}
			finally
			{
				if (oAccount != null)
					ServicedComponent.DisposeObject((ServicedComponent)oAccount);

			}

		}
		
		/// <summary>
		/// Map account adddress with retrieve address middleware response
		/// </summary>
		/// <param name="address"></param>
		/// <param name="retrieveAddressResponse"></param>
        public static void GetCreditCardAddress(AccountAddress address, RetrieveAddressResponse retrieveAddressResponse)
        {
            if (retrieveAddressResponse != null)
            {
                if (retrieveAddressResponse.AddressDetails != null)
                {

                    if (retrieveAddressResponse.AddressDetails.Any())
                    {
                        foreach (var addressDetail in retrieveAddressResponse.AddressDetails)
                        {
                            if (addressDetail.AccountNumber == address.AssociateAccountNumber)
                            {
                                var address1 = addressDetail.Address1;
                                var address2 = addressDetail.Address2;
                                var address3 = addressDetail.Address3;
                                var address4 = addressDetail.Address4;
                                var postCode = addressDetail.PostCode;
                                address.Address = Utility.Utility.Join(", ", address1, address2, address3, address4,
                                                                       postCode);
                                return;
                            }
                        }
                        address.Address = null;
                    }
                }
            }
        }

		/// <summary>
		/// Gets customers billpayment accoutstems.
		/// </summary>
		/// <returns></returns>
		public static string GetBillPaymentAccountStems(string sSessionGUID, string sAppID, string sChannelID, string sCustomerNumber, out DataSet dsBPAccountStems)
		{
			//TTW 31187

			string sxml;
			string sResult;
			DataSet dsData = new DataSet();	
			
			dsBPAccountStems = new DataSet();
						
			sResult = GetProductsByCustomer(sSessionGUID, sAppID,sChannelID, "12", sCustomerNumber, "", out sxml);
			
			if (sResult == Constants.SUCCESS && sxml != "")
			{

				//load xml into dataset
				dsData.ReadXml(new System.IO.StringReader(sxml),System.Data.XmlReadMode.InferSchema);

				DataTable dtAccountNames = new DataTable("AccountNames"); //datatable to hold Section_CPIA
				DataTable dtAccountDetails = new DataTable("AccountDetails"); //datatable to hold Section_CPID, Section_CPII, Section_CPIL, Section_CPIU

				//Build AccountNames table
				dtAccountNames.Columns.Add("AcctUniqueNzbaNumb");
				dtAccountNames.Columns.Add("AcctName");
   
				//Build AccountDetails table
				dtAccountDetails.Columns.Add("AcctUniqueNzbaNumb",System.Type.GetType("System.String"));
				dtAccountDetails.Columns.Add("AcctAccessNumb",System.Type.GetType("System.String"));
				dtAccountDetails.Columns.Add("ProdNumb",System.Type.GetType("System.String"));
				dtAccountDetails.Columns.Add("ProdDesc",System.Type.GetType("System.String"));
				dtAccountDetails.Columns.Add("ProdAttributes",System.Type.GetType("System.Int32"));
				dtAccountDetails.Columns.Add("NoOfSignaturesRequired",System.Type.GetType("System.Int32")); //TTW 44900..Return No of Signatures Required info, used to determine if an account is a 2tosign account


				//add the tables to the out dataset
				dsBPAccountStems.Tables.Add(dtAccountNames);
				dsBPAccountStems.Tables.Add(dtAccountDetails);

				//populate AccountNames table
				if (dsData.Tables.Contains("Section_CPIA"))
				{
					foreach (DataRow row in dsData.Tables["Section_CPIA"].Rows)
					{
						//Build datatable, excluding pago wallet accounts, i.e. bank and branch of '0123456'
						if (row["AcctUniqueNzbaNumb"].ToString().IndexOf("0123456") != 0)
							dtAccountNames.Rows.Add(new object[] {row["AcctUniqueNzbaNumb"],row["AcctName"]});  

					}
				}

				//holds tablenames that we want to load the data into AccountDetails tables
				string[] Sections = new string[] {"Section_CPID","Section_CPII","Section_CPIL","Section_CPIU"};
                
				//poulate AccountDetails table
				for (int i=0;i<Sections.Length;i++)
				{
					if (dsData.Tables.Contains(Sections[i]))
					{
						foreach (DataRow row in dsData.Tables[Sections[i]].Rows)
						{
							int iNoOfSigReq = 0;
							if (row.Table.Columns.Contains("SigtReqd") && row["SigtReqd"].ToString() != "")
								iNoOfSigReq = int.Parse(row["SigtReqd"].ToString());
							//TTW 44900 - Exclude 2ToSign accounts
							if (iNoOfSigReq < 2) 
								dtAccountDetails.Rows.Add(new object[] {row["AcctUniqueNzbaNumb"],
																		   row["AcctAccessNumb"],
																		   row["ProdNumb"],
																		   row["ProdDescription"],
																		   int.Parse(row["ProdAttributes"].ToString()),
																		   iNoOfSigReq});
						}				
						
					}

				}

			}

			return Constants.SUCCESS; 

		}

		
		public static string GetAccounts(string sAppID,string sChannelID, string sCustomerNumber, out FNCDataSets.FNCData dsAccounts)
		{
			return GetAccounts(null, sAppID, sChannelID, sCustomerNumber, out dsAccounts);
		}
		/// <summary>
		/// This functions get list of user accounts
		/// </summary>
		/// <returns></returns>
		public static string GetAccounts(string sSessionGUID, string sAppID,string sChannelID, string sCustomerNumber, out FNCDataSets.FNCData dsAccounts)
		{

			string sxml;
			string sResult;
			DataSet dsData = new DataSet();
			DataTable dtRawAccounts;
			DataTable dtNames;
			dsAccounts = new FNCDataSets.FNCData();
			FNCDataSets.FNCData.AccountsDataTable dtAccounts =  dsAccounts.Accounts;
			
			sResult = GetProductsByCustomer(sSessionGUID, sAppID,sChannelID, "12", sCustomerNumber, "", out sxml);
			if (sResult == Constants.SUCCESS)
			{
				dsData.ReadXml( new System.IO.StringReader(sxml),XmlReadMode.InferSchema);

				if (dsData.Tables.Contains("Section_CPID")) //TTW 31178
				{
					dtRawAccounts = dsData.Tables["Section_CPID"];	
					dtNames = dsData.Tables["Section_CPIA"];
					for(int i=0;i<dtRawAccounts.Rows.Count;i++)
					{
						string personalisedName =  dtRawAccounts.Rows[i]["AcctPersonalisedName"].ToString();
						dtNames.DefaultView.RowFilter = "AcctUniqueNzbaNumb = " + dtRawAccounts.Rows[i]["AcctUniqueNzbaNumb"].ToString();
						dtAccounts.AddAccountsRow(dtRawAccounts.Rows[i]["AcctUniqueNzbaNumb"].ToString() +
							dtRawAccounts.Rows[i]["AcctSufxNzbaNumb"].ToString(), 
							dtNames.DefaultView[0]["AcctName"].ToString(), 
							Decimal.Parse(dtRawAccounts.Rows[i]["AcctAvailableBalAmt"].ToString())/100,
							((string)("00" + dtRawAccounts.Rows[i]["AcctAccessNumb"].ToString())).TrimStart(new char[]{'0'}).PadLeft(2,'0'),
							dtRawAccounts.Rows[i]["ProdDescription"].ToString(),
							int.Parse(dtRawAccounts.Rows[i]["AcctClosedFlag"].ToString()) == 1,
							int.Parse(dtRawAccounts.Rows[i]["ProdAttributes"].ToString()),
							int.Parse(dtRawAccounts.Rows[i]["ProdNumb"].ToString()),
							Decimal.Parse(dtRawAccounts.Rows[i]["AcctLedgerBalAmt"].ToString())/100,
							Decimal.Parse(dtRawAccounts.Rows[i]["AcctOvdtLimitFormalAmt"].ToString())/100,
							dtRawAccounts.Rows[i]["SigtReqd"].ToString() == "" ? 0 : int.Parse(dtRawAccounts.Rows[i]["SigtReqd"].ToString()),
							personalisedName, dtRawAccounts.Rows[i]["PitmHoldExistsFlag"].ToString() == "Y" ? true : false
							);
					}

				}

			}

			return sResult;

		}

		public static bool IsCCRegistered(string sSessionGUID, string sAppID, string sChannelID, string sCustomerNumber)
		{
			string sxml;
			string sResult;
            DataSet dsData = new DataSet();
						
			sResult = GetProductsByCustomer(sSessionGUID, sAppID,sChannelID, "12", sCustomerNumber, "", out sxml, false);
		
			if (sResult == Constants.SUCCESS)
			{
                dsData.ReadXml(new System.IO.StringReader(sxml), XmlReadMode.InferSchema);

                if (dsData.Tables.Contains("Section_CPIC"))
                {
                    // Check to see the number of closed credit cards a customer has
                    int counter = 0;
                    foreach (DataRow row in dsData.Tables["Section_CPIC"].Rows)
                    {
                        //exclude closed credit cards
                        if (row["AccountStatus"].ToString().Length > 0)
                        {
                            counter++;
                        }
                    }
                    // If the number of closed credit cards is the same as the total number 
                    // of credit cards then return false.
                    if (dsData.Tables["Section_CPIC"].Rows.Count == counter)
                        return false;
                    else
                        return true;
                }

				/*XmlDocument sResultXML = new XmlDocument();
				sResultXML.LoadXml(sxml);
                if (sResultXML.GetElementsByTagName("Section_CPIC").Count == 0)
                    return false;
                else
                    return true;*/
			}

			return false;
		}
		
		
		/// <summary>
		/// If there are at least 1 loyalty cards for this customer then yes.
		/// </summary>
        public static bool IsTrueRewardsRegistered(string sSessionGUID, string sAppID, string sChannelID, string sCustomerNumber, string sHostUsername)
		{
			if (GetNumTrueRewardsAccountsRegistered(sSessionGUID, sAppID, sChannelID, sCustomerNumber, sHostUsername) == 0)
				return false;
			else
				return true;
		}

		/// <summary>
		/// How many TR cards are associated with this customer? (count number of Loyalty Carsd in Section_CPIC)
		/// </summary>
        public static int GetNumTrueRewardsAccountsRegistered(string sSessionGUID, string sAppID, string sChannelID, string sCustomerNumber, string sHostUsername)
		{
			string sXML;
			string sResult;
						
			sResult = GetProductsByCustomer(sSessionGUID, sAppID,sChannelID, "12", sCustomerNumber, sHostUsername, out sXML, true);
			
			if (sResult == Constants.SUCCESS)
			{
				XmlDocument doc = new XmlDocument();
				doc.LoadXml(sXML);
				return doc.SelectNodes("//Section_CPIC[(starts-with(CrCardNumb, '5000512')) and (AccountStatus='')]").Count;
			}
			else
				return 0;
		}
		
        private static decimal GetLedgerBalance(string cardLedgerBalance)
        {
            decimal ledgerAmount = 0m;
            try
            {
                ledgerAmount = decimal.Parse(cardLedgerBalance);
            }
            catch
            {
                ledgerAmount = 0;
            }

            return ledgerAmount;
        }

		public static string GetCCAccounts(string sSessionGUID, string sAppID, string sChannelID, string sCustomerNumber, bool bIsTrueRewardsJoin, out XmlNodeList oCPIANodeList)
		{
			string sXML;
			string sResult;
			DataSet dsData = new DataSet();
			oCPIANodeList = null;

			sResult = GetProductsByCustomer(sSessionGUID, sAppID, sChannelID, "12", sCustomerNumber, "", out sXML);

			if(sResult == Constants.SUCCESS)
			{	
				XmlDocument oDoc = new XmlDocument();
				oDoc.LoadXml(sXML);

				oCPIANodeList = ExtractCreditCardsFromCPIExcludeTrueReward(oDoc, bIsTrueRewardsJoin, true);
			}
			return sResult;
		}

        public static string GetCCAccountNode(string sSessionGUID, string sAppID, string sChannelID, string sCustomerNumber, string sCardNumber, out XmlNode oCPICNode)
        {
            string sXML;
            string sResult;
            oCPICNode = null;

            sResult = GetProductsByCustomer(sSessionGUID, sAppID, sChannelID, "12", sCustomerNumber, "", out sXML);

            if (sResult == Constants.SUCCESS)
            {
                XmlDocument oDoc = new XmlDocument();
                oDoc.LoadXml(sXML);
                oCPICNode = oDoc.SelectSingleNode("//Section_CPIC[(CrCardNumb ='" + sCardNumber + "')]");
            }
            return sResult;
        }

		public static string GetAllAccounts(string sAppID,string sChannelID, string sCustomerNumber, out FNCDataSets.FNCData dsAccounts)
		{
			return GetAllAccounts(null, sAppID, sChannelID, sCustomerNumber, out dsAccounts);
		}

		/// <summary>
		/// Return the entire ProductXML without modifications.
		/// </summary>
		/// <param name="sSessionGUID"></param>
		/// <param name="sAppId"></param>
		/// <param name="sChannelId"></param>
		/// <param name="sHostUsername"></param>
		/// <param name="sCustomerNumber"></param>
		/// <param name="sProductXml"></param>
		/// <returns></returns>
		public static string GetAllAccounts(string sSessionGUID, string sAppId, string sChannelId, string sHostUsername,
			string sCustomerNumber, out string sProductXml)
		{
			return GetProductsByCustomer(sSessionGUID, sAppId, sChannelId, "12", sCustomerNumber,
				sHostUsername, out sProductXml);
		}

		/// <summary>
		/// This function gets a list of all the user's accounts including credit card accounts.
		/// </summary>
		/// <returns></returns>
		public static string GetAllAccounts(string sSessionGUID, string sAppID,string sChannelID, string sCustomerNumber, out FNCDataSets.FNCData dsAccounts)
		{
			string sxml;
			string sResult;
			DataSet dsData = new DataSet();
			DataTable dtRawAccounts;
			DataTable dtCCAccounts; //credit card accounts
			DataTable dtNames;
			dsAccounts = new FNCDataSets.FNCData();
			FNCDataSets.FNCData.AccountsDataTable dtAccounts =  dsAccounts.Accounts;
			
			sResult = GetProductsByCustomer(sSessionGUID, sAppID,sChannelID, "12", sCustomerNumber, "", out sxml);
			if (sResult == Constants.SUCCESS)
			{
				dsData.ReadXml( new System.IO.StringReader(sxml), XmlReadMode.InferSchema);
				dtNames = dsData.Tables["Section_CPIA"];

				//Add accounts if exists
				if (dsData.Tables.Contains("Section_CPID"))
				{
					dtRawAccounts = dsData.Tables["Section_CPID"];
					for(int i=0;i<dtRawAccounts.Rows.Count;i++)
					{
						dtNames.DefaultView.RowFilter = "AcctUniqueNzbaNumb = " + dtRawAccounts.Rows[i]["AcctUniqueNzbaNumb"].ToString();
						dtAccounts.AddAccountsRow(dtRawAccounts.Rows[i]["AcctUniqueNzbaNumb"].ToString() +
							dtRawAccounts.Rows[i]["AcctSufxNzbaNumb"].ToString(), 
							dtNames.DefaultView[0]["AcctName"].ToString(),
							Decimal.Parse(dtRawAccounts.Rows[i]["AcctAvailableBalAmt"].ToString())/100,
							((string)("00" + dtRawAccounts.Rows[i]["AcctAccessNumb"].ToString())).TrimStart(new char[]{'0'}).PadLeft(2,'0'),
							dtRawAccounts.Rows[i]["ProdDescription"].ToString(),
							int.Parse(dtRawAccounts.Rows[i]["AcctClosedFlag"].ToString()) == 1,
							int.Parse(dtRawAccounts.Rows[i]["ProdAttributes"].ToString()),
							int.Parse(dtRawAccounts.Rows[i]["ProdNumb"].ToString()),
							Decimal.Parse(dtRawAccounts.Rows[i]["AcctLedgerBalAmt"].ToString())/100,
							Decimal.Parse(dtRawAccounts.Rows[i]["AcctOvdtLimitFormalAmt"].ToString())/100,
							dtRawAccounts.Rows[i]["SigtReqd"].ToString() == "" ? 0 : int.Parse(dtRawAccounts.Rows[i]["SigtReqd"].ToString()),
							dtRawAccounts.Rows[i]["AcctPersonalisedName"].ToString(), 
							dtRawAccounts.Rows[i]["PitmHoldExistsFlag"].ToString() == "Y" ? true : false
							);
					}
				}

				//Add credit card accounts if exists
				if (dsData.Tables.Contains("Section_CPIC"))
				{
					dtCCAccounts = dsData.Tables["Section_CPIC"];
					foreach (DataRow CreditRow in dtCCAccounts.Rows)
					{
						string csBal  = CreditRow["CrCardAvailableBalAmt"].ToString();
						string csProd = CreditRow["ProdAttributes"].ToString();
						string csProdNum = CreditRow["ProdNumb"].ToString();
						string csBalAmt = CreditRow["CrCardLedgerBalAmt"].ToString();

						dtAccounts.AddAccountsRow(CreditRow["CrCardNumb"].ToString(), 
							String.Empty, //no account name returned for credit cards
							Decimal.Parse((csBal == "")?"0":csBal)/100,
							"C", //instead of storing an access number we store a flag here to indicate a credit card type
							CreditRow["ProdDescription"].ToString(),
							false,
							int.Parse((csProd == "")?"0":csProd),
							int.Parse((csProdNum == "")?"0":csProdNum),
							Decimal.Parse((csBalAmt == "")?"0":csBalAmt)/100,
							0,0, string.Empty, /* personalised account name */
							CreditRow["PitmHoldExistsFlag"].ToString() == "Y" ? true : false);
					}
				}

				//Add Term Investment accounts if exists
				if (dsData.Tables.Contains("Section_CPII"))
				{
					dtRawAccounts = dsData.Tables["Section_CPII"];
					for(int i=0;i<dtRawAccounts.Rows.Count;i++)
					{
						dtNames.DefaultView.RowFilter = "AcctUniqueNzbaNumb = " + dtRawAccounts.Rows[i]["AcctUniqueNzbaNumb"].ToString();
						dtAccounts.AddAccountsRow(dtRawAccounts.Rows[i]["AcctUniqueNzbaNumb"].ToString() +
							dtRawAccounts.Rows[i]["AcctSufxNzbaNumb"].ToString(), 
							dtNames.DefaultView[0]["AcctName"].ToString(),0,"","",false,0,0,0,0,
							dtRawAccounts.Rows[i]["SigtReqd"].ToString() == "" ? 0 : int.Parse(dtRawAccounts.Rows[i]["SigtReqd"].ToString()), 
							string.Empty /* personalised account name */, 
							dtRawAccounts.Rows[i]["PitmHoldExistsFlag"].ToString() == "Y" ? true : false);
					}
				}

			}
			return sResult;
		}

        public static string GetCreditCardAccounts(string sSessionGUID, string sAppID, string sChannelID, string sCustomerNumber, out FNCDataSets.FNCData dsCreditCards)
        {
            string sResult;
            string sXML;
            DataSet dsData = new DataSet();
            DataTable dtCCAccounts;
            dsCreditCards = new FNCDataSets.FNCData();
            FNCDataSets.FNCData.AccountsDataTable dtAccounts = dsCreditCards.Accounts;            

            sResult = GetProductsByCustomer(sSessionGUID, sAppID, sChannelID, "12", sCustomerNumber, "", out sXML);
            if (sResult == Constants.SUCCESS)
            {
                dsData.ReadXml(new System.IO.StringReader(sXML), XmlReadMode.InferSchema);

                if (dsData.Tables.Contains("Section_CPIC"))
                {
                    dtCCAccounts = dsData.Tables["Section_CPIC"];
                    foreach (DataRow CreditRow in dtCCAccounts.Rows)
                    {
                        string csBal = CreditRow["CrCardAvailableBalAmt"].ToString();
                        string csProd = CreditRow["ProdAttributes"].ToString();
                        string csProdNum = CreditRow["ProdNumb"].ToString();
                        string csBalAmt = CreditRow["CrCardLedgerBalAmt"].ToString();

                        dtAccounts.AddAccountsRow(CreditRow["CrCardNumb"].ToString(),
                            String.Empty, Decimal.Parse((csBal == "") ? "0" : csBal) / 100,
                            "C",  CreditRow["ProdDescription"].ToString(),
                            false, int.Parse((csProd == "") ? "0" : csProd),
                            int.Parse((csProdNum == "") ? "0" : csProdNum),
                            Decimal.Parse((csBalAmt == "") ? "0" : csBalAmt) / 100,
                            0, 0, string.Empty, /* personalised account name */
                            CreditRow["PitmHoldExistsFlag"].ToString() == "Y" ? true : false);
                    }                   
                }

            }
            return sResult;
        }


		public static string GetFeeAccounts(string sSessionGUID, string sAppId, string sChannelId,
			string sBankNumber, string sCustomerNumber, string sHostUserName, string sAccountUniqueNZBA,
			out bool isCurrentAccountFeeAccount, out FeeAccountDetail[] feeAccountDetails, bool excludeGroup)
		{
			string sxml = string.Empty;
			feeAccountDetails = null;

			

			isCurrentAccountFeeAccount = false;
			string sResult = 
				GetProductsByCustomer(sSessionGUID, sAppId, sChannelId, sBankNumber, sCustomerNumber, sHostUserName, out sxml);
			
			XmlDocument xdoc = new XmlDocument();
			xdoc.LoadXml(sxml);

			string accountName = string.Empty;
			int productNumber;
			string suffixNumber = string.Empty;
			ArrayList suffixList = new ArrayList();
			XmlDocument feeAcctDoc = new XmlDocument();
			string[] suffixes = null;

			string uniqueNumber = sAccountUniqueNZBA;
			if (uniqueNumber.Length != 15)
				uniqueNumber = sAccountUniqueNZBA.Substring(0,15);
			
			XmlNode xNode = xdoc.SelectSingleNode(string.Format("/TMResponse/Section_CPIA[AcctUniqueNzbaNumb='{0}']/AcctName", uniqueNumber));
			if (xNode != null)
				accountName = xNode.InnerText;
		
			string filterExpression = string.Format("/TMResponse/Section_CPID[AcctUniqueNzbaNumb='{0}' and AcctFeeFlag='Y']",uniqueNumber );
			xNode = xdoc.SelectSingleNode(filterExpression);
			if (xNode != null)
			{
				isCurrentAccountFeeAccount = true;
				FeeAccountDetail feeAccountDetail = FeeAccountDetail.Create(accountName, xNode);					
				feeAccountDetails = new FeeAccountDetail[]{feeAccountDetail};

				return sResult;
			}
			
			if(excludeGroup)
			{
				/*
				 * The prodGroup array is searched using Array.BinarySearch() latter on within this method. 
				 * The array on which a binary seach is applied must be SORTED.
				 * 
				 * http://www.4guysfromrolla.com/articles/110602-1.2.aspx
				 */ 
				Array.Sort(prodGroup);

				XmlNodeList accountNodeList = xdoc.SelectNodes(string.Format("/TMResponse/Section_CPID[AcctUniqueNzbaNumb=" + uniqueNumber + "]"));
				foreach(XmlNode acctNode in accountNodeList)
				{
					productNumber = Convert.ToInt32(acctNode.SelectSingleNode("ProdNumb").InnerText);
					suffixNumber = acctNode.SelectSingleNode("AcctSufxNzbaNumb").InnerText;
					int indexAccount = Array.BinarySearch(prodGroup, productNumber);
					if(indexAccount >= 0)
						suffixList.Add(suffixNumber);
				}
				if(suffixList.Count > 0)
					suffixes = (string[])suffixList.ToArray(System.Type.GetType("System.String"));
			}

			string xml = string.Empty;
			if (!isCurrentAccountFeeAccount)
			{
				// TTW 46159 Call .NET interface instead of VB6 interface - the .NET interface returns XML directly.
				ASB.BC.Account.IPayment_2008_1 oBillPayment = null;
				
				try
				{
					oBillPayment = new ASB.BC.Account.Payment();
				
					sResult = oBillPayment.GetBillPaymentFeeAccounts(sAppId, sChannelId, sHostUserName, sAccountUniqueNZBA, out xml);
				}
				finally 
				{
					if (oBillPayment != null && oBillPayment is IDisposable)
						((IDisposable)oBillPayment).Dispose();
				}
				if (sResult == ASB.Utility.Common.Constants.SUCCESS)
				{
					if(excludeGroup && suffixList.Count > 0)
					{					
						feeAcctDoc.LoadXml(xml);
						foreach(XmlNode oNode in feeAcctDoc.SelectNodes("//Section_427S"))
						{
							string suffix = oNode.SelectSingleNode("AcctSufxNumb").InnerText.PadLeft(4,'0');						
							int indexSuffix = Array.BinarySearch(suffixes, suffix);
							if(indexSuffix >= 0)
								feeAcctDoc.SelectSingleNode("//xmlResults").RemoveChild(oNode);
						}
						xml = feeAcctDoc.InnerXml;
					}

					BillPaymentFeeAccountResponse billFeeAccount = BillPaymentFeeAccountResponse.Create(xml);
					if (billFeeAccount != null && billFeeAccount.billPaymentFeeAccountArray != null)
					{
						feeAccountDetails = new FeeAccountDetail[billFeeAccount.billPaymentFeeAccountArray.Length];
						int index = 0;
						foreach(BillPaymentFeeAccount account in billFeeAccount.billPaymentFeeAccountArray)
						{
							FeeAccountDetail feeAccountDetail = new FeeAccountDetail();
							feeAccountDetail.AccountName = accountName;
							feeAccountDetail.AcctAccessNumb = "AccCode";
							feeAccountDetail.AcctSufxNzbaNumb = account.NZBAAccountSuffix.PadLeft(4, '0');
							feeAccountDetail.AcctUniqueNzbaNumb = sAccountUniqueNZBA;
							feeAccountDetail.ProdDescription = "ProdDesc";
							feeAccountDetail.PersonalisedName = account.PersonalisedName;
							feeAccountDetails[index] = feeAccountDetail;
							index++;
						}
					}
				}
			}


			return sResult;
		}

		//This method return all fee accounts for the selected sAccountUniqueNZBA
		//ttw 52273 remove from the fee accounts following products:174,342,617,625,633,641,1089,1097,3615
		//TTW 28669 filter Debt Recovery Account(2073) for NetDirect
		//HomePlus - Productnumber 4511
		public static string GetFeeAccounts(string sSessionGUID, string sAppId, string sChannelId,
			string sBankNumber, string sCustomerNumber, string sHostUserName, string sAccountUniqueNZBA,
			out FeeAccountDetail[] feeAccountDetails, bool excludeGroup)
		{
			string sxml = string.Empty;
			ArrayList al = new ArrayList();
			feeAccountDetails = null;
				

			string sResult = 
				GetProductsByCustomer(sSessionGUID, sAppId, sChannelId, sBankNumber, sCustomerNumber, sHostUserName, out sxml);
			
			XmlDocument xdoc = new XmlDocument();
			xdoc.LoadXml(sxml);

			string accountName = string.Empty;
			int productNumber;
			string suffixNumber = string.Empty;
			ArrayList suffixList = new ArrayList();
			XmlDocument feeAcctDoc = new XmlDocument();
			string[] suffixes = null;

			string uniqueNumber = sAccountUniqueNZBA;
			if (uniqueNumber.Length != 15)
				uniqueNumber = sAccountUniqueNZBA.Substring(0,15);
			
			XmlNode xNode = xdoc.SelectSingleNode(string.Format("/TMResponse/Section_CPIA[AcctUniqueNzbaNumb='{0}']/AcctName", uniqueNumber));
			if (xNode != null)
				accountName = xNode.InnerText;
			if(excludeGroup)
			{
			   /*
				* The prodGroup array is searched using Array.BinarySearch() latter on within this method. 
				* The array on which a binary seach is applied must be SORTED.
				* 
				* http://www.4guysfromrolla.com/articles/110602-1.2.aspx
				*/ 
				Array.Sort(prodGroup);

				XmlNodeList accountNodeList = xdoc.SelectNodes(string.Format("/TMResponse/Section_CPID[AcctUniqueNzbaNumb=" + uniqueNumber + "]"));
				foreach(XmlNode acctNode in accountNodeList)
				{
					productNumber = Convert.ToInt32(acctNode.SelectSingleNode("ProdNumb").InnerText);
					suffixNumber = acctNode.SelectSingleNode("AcctSufxNzbaNumb").InnerText;
					int indexAccount = Array.BinarySearch(prodGroup, productNumber);
					if(indexAccount >= 0)
						suffixList.Add(suffixNumber);
				}
				if(suffixList.Count > 0)
					suffixes = (string[])suffixList.ToArray(System.Type.GetType("System.String"));
			}

			string xml = string.Empty;
			
			// TTW 46159 Call .NET interface instead of VB6 interface - the .NET interface returns XML directly.
			ASB.BC.Account.IPayment_2008_1 oBillPayment = null;
				
			try
			{
				oBillPayment = new ASB.BC.Account.Payment();
				
				sResult = oBillPayment.GetBillPaymentFeeAccounts(sAppId, sChannelId, sHostUserName, sAccountUniqueNZBA, out xml);
			}
			finally 
			{
				if (oBillPayment != null && oBillPayment is IDisposable)
					((IDisposable)oBillPayment).Dispose();
			}
			if (sResult == ASB.Utility.Common.Constants.SUCCESS)
			{
				if(excludeGroup && suffixList.Count > 0)
				{					
					feeAcctDoc.LoadXml(xml);
					foreach(XmlNode oNode in feeAcctDoc.SelectNodes("//Section_427S"))
					{
						string suffix = oNode.SelectSingleNode("AcctSufxNumb").InnerText.PadLeft(4,'0');						
						int indexSuffix = Array.BinarySearch(suffixes, suffix);
						if(indexSuffix >= 0)
							feeAcctDoc.SelectSingleNode("//xmlResults").RemoveChild(oNode);
					}
					xml = feeAcctDoc.InnerXml;
				}

				BillPaymentFeeAccountResponse billFeeAccount = BillPaymentFeeAccountResponse.Create(xml);
				if (billFeeAccount != null && billFeeAccount.billPaymentFeeAccountArray != null)
				{					
					int index = 0;
					foreach(BillPaymentFeeAccount account in billFeeAccount.billPaymentFeeAccountArray)
					{						
						FeeAccountDetail feeAccountDetail = new FeeAccountDetail();
						feeAccountDetail.AccountName = accountName;
						feeAccountDetail.AcctAccessNumb = "AccCode";
						feeAccountDetail.AcctSufxNzbaNumb = account.NZBAAccountSuffix.PadLeft(4, '0');
						feeAccountDetail.AcctUniqueNzbaNumb = sAccountUniqueNZBA;
						feeAccountDetail.ProdDescription = "ProdDesc";
						feeAccountDetail.PersonalisedName = account.PersonalisedName;
							
						if(xdoc.SelectSingleNode(string.Format("/TMResponse/Section_CPID[AcctUniqueNzbaNumb='{0}' and AcctSufxNzbaNumb='{1}']/ProdNumb", sAccountUniqueNZBA, feeAccountDetail.AcctSufxNzbaNumb)) != null)
						{
							feeAccountDetail.ProductNumber = int.Parse(xdoc.SelectSingleNode(string.Format("/TMResponse/Section_CPID[AcctUniqueNzbaNumb='{0}' and AcctSufxNzbaNumb='{1}']/ProdNumb", sAccountUniqueNZBA, feeAccountDetail.AcctSufxNzbaNumb)).InnerText);
							
							/*
							 * TTW 28669 - Access Number and Product description are required for the fee deductable accounts
							 * which are to be displayed within NetDriect
							 */ 
							if(sChannelId == FNC.Utility.Constants.NETDIRECT)
							{
								feeAccountDetail.AcctAccessNumb = xdoc.SelectSingleNode(string.Format("/TMResponse/Section_CPID[AcctUniqueNzbaNumb='{0}' and AcctSufxNzbaNumb='{1}']/AcctAccessNumb", sAccountUniqueNZBA, feeAccountDetail.AcctSufxNzbaNumb)).InnerText;
								feeAccountDetail.ProdDescription = xdoc.SelectSingleNode(string.Format("/TMResponse/Section_CPID[AcctUniqueNzbaNumb='{0}' and AcctSufxNzbaNumb='{1}']/ProdDescription", sAccountUniqueNZBA, feeAccountDetail.AcctSufxNzbaNumb)).InnerText;
							}

							al.Add(feeAccountDetail);
							index++;			
						}
					}
					feeAccountDetails = (FeeAccountDetail[])al.ToArray(typeof(FeeAccountDetail));
				}
			}
			

			return sResult;
		}

		public static string PopulateNetcodeFeeAccountDetails(string sSessionGUID, string sAppId, string sChannelId,
			string sBankNumber, string sCustomerNumber, CurrentNetcodeFeeDeductionAccount netcodeFeeDeductionAccount)
		{	
			string sResult = String.Empty;
			string sXML;

			if(netcodeFeeDeductionAccount.IsFeeAccountSpecified())
			{
				sResult = GetProductsByCustomer(sSessionGUID, sAppId, sChannelId, sBankNumber, sCustomerNumber, "", out sXML);
			
				if (sResult == Constants.SUCCESS)
				{
					XmlDocument xdoc = new XmlDocument();
					xdoc.LoadXml(sXML);

					string uniqueNumber = netcodeFeeDeductionAccount.FeeAccount.Substring(0,15);
					string suffixNumber = netcodeFeeDeductionAccount.FeeAccount.Substring(15).PadLeft(4, '0');
					
					XmlNode xNode = xdoc.SelectSingleNode(string.Format("/TMResponse/Section_CPID[AcctUniqueNzbaNumb='{0}' and AcctSufxNzbaNumb='{1}']/ProdNumb", uniqueNumber, suffixNumber));
					XmlNode xNodeSigtReqd = xdoc.SelectSingleNode(string.Format("/TMResponse/Section_CPID[AcctUniqueNzbaNumb='{0}' and AcctSufxNzbaNumb='{1}']/SigtReqd", uniqueNumber, suffixNumber));

					//If the account is not returned by the call to GetProductsByCustomer, we can assume that it is closed
					if(xNode == null || (xNodeSigtReqd != null && xNodeSigtReqd.InnerText.Length != 0 &&  Convert.ToInt32(xNodeSigtReqd.InnerXml) > 1))
					{
						netcodeFeeDeductionAccount.Closed = true;
					}
					else
					{
						netcodeFeeDeductionAccount.Closed = false;
						
						//For FASTNET, we want the personalised name of the account, if it exists
						if(sChannelId == FNC.Utility.Constants.FASTNETC)
						{
							string personalisedName = xdoc.SelectSingleNode(string.Format("/TMResponse/Section_CPID[AcctUniqueNzbaNumb='{0}' and AcctSufxNzbaNumb='{1}']/AcctPersonalisedName", uniqueNumber, suffixNumber)).InnerText;
							if(personalisedName!=null && !personalisedName.Equals(""))
							{
								netcodeFeeDeductionAccount.PersonalisedName = personalisedName;
							}
						}
							//For Netdirect, we want the Access code and Product description
						else if(sChannelId == FNC.Utility.Constants.NETDIRECT)
						{
							netcodeFeeDeductionAccount.AccessNumber = xdoc.SelectSingleNode(string.Format("/TMResponse/Section_CPID[AcctUniqueNzbaNumb='{0}' and AcctSufxNzbaNumb='{1}']/AcctAccessNumb", uniqueNumber, suffixNumber)).InnerText;
							netcodeFeeDeductionAccount.ProductDescription = xdoc.SelectSingleNode(string.Format("/TMResponse/Section_CPID[AcctUniqueNzbaNumb='{0}' and AcctSufxNzbaNumb='{1}']/ProdDescription", uniqueNumber, suffixNumber)).InnerText;
						}
					}
				}
			}
			
			return sResult;
		}

		public static string GetSumTermFund(string sSessionGUID, string sAppID, string sChannelID,
            string sCustomerNumber, string sProductNumber, string accountNumber, out decimal balance)
		{
			string sResult;
			string sXML;
			balance = 0;
			XmlDocument oDom = new XmlDocument();
            
			sResult = GetProductsByCustomer(sSessionGUID, sAppID,sChannelID, "12", sCustomerNumber, "", out sXML);

			if (sResult == Constants.SUCCESS)
			{
				oDom.LoadXml(sXML);
                XmlNodeList investmentNodeList = oDom.SelectNodes(string.Format("/TMResponse/Section_CPII[ProdNumb='{0}' and AcctUniqueNzbaNumb='{1}']", sProductNumber, accountNumber));              
				foreach(XmlNode oNode in investmentNodeList)
				{
					decimal acctLedgerBalance = GetLedgerBalance(oNode.SelectSingleNode("AcctLedgerBalAmt").InnerText)/100;
					balance = balance + acctLedgerBalance;
				}
				
			}
			return sResult;	

		}

		public static void Flush(string sessionID)
		{
			ASB.CBO.DA.Session.DeleteByMultipleTypes(sessionID,
				(long)(ASB.CBO.DA.Util.FNCCIT_CacheItemTypes.FNCCIT_STATEMENT_REQUEST |
				ASB.CBO.DA.Util.FNCCIT_CacheItemTypes.FNCCIT_STATEMENT_PAGE |
				ASB.CBO.DA.Util.FNCCIT_CacheItemTypes.FNCCIT_BALANCES |
				ASB.CBO.DA.Util.FNCCIT_CacheItemTypes.FNCCIT_FASTCHEQUE_REQUEST |
				ASB.CBO.DA.Util.FNCCIT_CacheItemTypes.FNCCIT_FEE_ACCOUNTS | 
				ASB.CBO.DA.Util.FNCCIT_CacheItemTypes.FNCCIT_FASTCHEQUE_ACCOUNTS |
				ASB.CBO.DA.Util.FNCCIT_CacheItemTypes.FNCCIT_TRANSFER_REQUEST |
				ASB.CBO.DA.Util.FNCCIT_CacheItemTypes.FNCCIT_WALLETS));

            FNCDASessionCache.SessionCacheClass vbSessionCache = new FNCDASessionCache.SessionCacheClass();
            vbSessionCache.DeleteFOACacheItem(sessionID, "AccountList");
        }

	
		public static string GetNewStatementForExport(ExportArgs exportArgs, out XmlDocument xml)
		{
			string sResult;

			long lStatementType = long.Parse(exportArgs.AccountType);
			long lProductNumber = long.Parse(exportArgs.ProductNumber);
			int lPageSize = 0;

			string ASB_Version1_0 = "1.0";
			string sStartSequence = ""; //not been used by now.. possibly for later use
			string sNextStartSequence;
			int lFetchedRows = 0;
			int lRowsToFetch = 0;

			DateTime datRequestTime = DateTime.Now;
			string[] listHeader = {lStatementType.ToString(),datRequestTime.ToString("d/MM/yyyy HH:mm:ss"), exportArgs.AccountName,exportArgs.AccountNumber,lProductNumber.ToString(),
									  exportArgs.ProductDescription,exportArgs.FromDate.ToShortDateString(),exportArgs.ToDate.ToShortDateString(),lPageSize.ToString(),exportArgs.CustomInfo};
			XmlDocument stmtHeader = CreatePageHeaderInfo(listHeader);

			//the pagesize will always be 0.
			if (lPageSize == 0)
				lRowsToFetch = 10005;
			if((lRowsToFetch >=0 || lPageSize == 0) && (lFetchedRows == 0 || (lStatementType != ASBBank.FNC.Utility.Constants.FNCCALRT_CREDCARD && lStatementType != ASBBank.FNC.Utility.Constants.FNCCALRT_LOYALTY)))
			{		
				if(lPageSize != 0 && lRowsToFetch == 0)
					lRowsToFetch = 1;
				switch (lStatementType)
				{
					case Utility.Constants.FNCCALRT_BANKACCT:
						sResult = GetAccountStatement(exportArgs.AppID,exportArgs.ChannelID,"",ASB_Version1_0,exportArgs.AccountNumber,exportArgs.FromDate,exportArgs.ToDate,sStartSequence,lRowsToFetch,out xml,out sNextStartSequence);
						if (sResult == Constants.SUCCESS)
						{
							AddHeader(xml, stmtHeader);
							UpdateSequences(xml, false, "//Tran", "TranDate", true);
						}
						else
						{
							try
							{
								xml.LoadXml(sResult);
								string errorDescription = "";
								XmlNode descriptionNode = xml.SelectSingleNode("//Error/Description");
								if (descriptionNode != null)
									errorDescription = descriptionNode.InnerText;
								throw new Exception(errorDescription.Trim());
							}
							catch(Exception ex)
							{
								throw new Exception(ex.Message);
							}
						}						
						break;
					case Utility.Constants.FNCCALRT_CREDCARD: 
					case Utility.Constants.FNCCALRT_LOYALTY:
						sResult = GetCCAccountStatement(exportArgs.AccountNumber,exportArgs.FromDate, exportArgs.ToDate, sStartSequence,true, out xml, out sNextStartSequence, exportArgs.ChannelID);
                        if (sResult == Constants.SUCCESS)
                        {
                            XmlNodeList ccHead = xml.SelectNodes("/xml/CCHDR");
                            foreach (XmlNode var in ccHead)
                            {
                                AddStmtInfoToCreditCard(xml, var, stmtHeader);
                            }
                            UpdateSequences(xml, false, "//CCSTD", "ValueDate");
                        }
                        else
                        {
							try
							{
								xml.LoadXml(sResult);
								string errorDescription = "";
								XmlNode descriptionNode = xml.SelectSingleNode("//Error/Description");
								if (descriptionNode != null)
									errorDescription = descriptionNode.InnerText;
								throw new Exception(errorDescription.Trim());
							}
							catch(Exception ex)
							{
								throw new Exception(ex.Message);
							}
                        }						
						break;
					default:
						throw new ArgumentException("Can't handle the following Statement Type: " + lStatementType);
				}
			}
			else
			{
				throw new ArgumentException("Unable to process with specified arguments");
			}

			if(sResult == Constants.SUCCESS)
			{			
				string sSessionId = string.Empty;
				string sBankNumber = "";
				string sCustomerNumber = "";
				string sFac = "";
				object oStatementBalances = new object();
				ADODB.Recordset rsStatementBalances = new ADODB.RecordsetClass();
				object dat2 = null;
				object dat3 = null;
				int iLogId;
		
				FNCDASessionCache._SessionCache oDACache = new FNCDASessionCache.SessionCacheClass();
				int lResult = oDACache.GetSessionAndCache(exportArgs.SessionID,
					(int)(ASB.CBO.DA.Util.FNCCIT_CacheItemTypes.FNCCIT_STATEMENT_REQUEST),
					"0", ref sBankNumber, ref sCustomerNumber,
					ref sFac, ref sSessionId, ref oStatementBalances, ref dat2, ref dat3);
				oDACache = null;		
	
				if(lResult == 0 && oStatementBalances != null)
				{
                    rsStatementBalances = FNC.BPCommon.FNCBPCommon.GetRecordsetFromBytes(ref oStatementBalances);
					string sFromAccount = rsStatementBalances.Fields[2].Value.ToString(); //[FNCCALF_ACCT_NUMB]	

                    Logging.AuditLog("StatementExport", exportArgs.IpAddress, System.Environment.MachineName, sFac, sFromAccount, "", 0, "", exportArgs.SessionID, exportArgs.ChannelID,
                        false, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty,
                        Convert.ToInt32(sCustomerNumber), out iLogId);					
				}				
			}

			return sResult;
		}

      
		public static void UpdateSequences(XmlDocument xml, bool fixDate, string tranSelectors, string dateSelector)
		{
			UpdateSequences(xml, fixDate, tranSelectors, dateSelector, false);
		}


		private static void UpdateSequences(XmlDocument xml, bool fixDate, string tranSelectors, string dateSelector, bool transactionalAccount)
		{
			int lastNum = 0;
			string lastDate = "";
			foreach (XmlElement node in xml.SelectNodes(tranSelectors))
			{
				XmlElement eDate = (XmlElement) node.SelectSingleNode(dateSelector);
				if(fixDate)
				{
					DateTime date = DateTime.Parse(eDate.InnerText);
					eDate.InnerText = date.ToString("yyyyMMdd");
				}
				string thisDate = eDate.InnerText;
				if(tranSelectors=="//CCSTD")
				{
					thisDate = DateTime.Parse(eDate.InnerText).ToString("yyyyMMdd");
				}
				if(lastDate != thisDate)
				{
					lastDate = thisDate;
					lastNum = 0;
				}
				if (transactionalAccount)
				{
					XmlElement tranDrAmt = (XmlElement) node.SelectSingleNode("TranDrAmt");
					XmlElement tranCrAmt = (XmlElement) node.SelectSingleNode("TranCrAmt");
					//Increment the sequence number when current element is not the first element (first element = empty string)
					//Also increment the sequence number when there is no node. This ensures no internal errors (assumption: 
					//this matches empty string scenario)
					//There is a filter in the Statements/Xslt/Input/Ta.xslt to filter out all the rows with TranDrAmt or TranCrAmt = null.
					if(tranDrAmt == null || tranCrAmt == null|| tranDrAmt.InnerText.ToString() != "" || tranCrAmt.InnerText.ToString() != "")
					{
						lastNum++;
					}
				}
				else 
				{
					lastNum++;
				}

				string s = thisDate+(lastNum < 10 ? "0" : "")+ lastNum;
				node.SetAttribute("FriendlySequenceNumber", s);
			}
		}

		private static void AddStmtInfoToCreditCard(XmlDocument target,XmlNode node, XmlDocument statementHeader)
		{
			XmlNode headerRoot = statementHeader.DocumentElement;
			XmlNodeList content = headerRoot.ChildNodes;

			foreach(XmlNode var in content)
			{
				XmlNode newNode = target.CreateNode(XmlNodeType.Element,var.Name,"");
				newNode.InnerText = var.InnerText;
				node.InsertAfter(newNode,node.LastChild);
			}

		}

		public static void AddHeader(XmlDocument document, XmlDocument headXml)
		{
			document.DocumentElement.PrependChild(document.ImportNode(headXml.DocumentElement,true));
		}

		private static XmlDocument CreatePageHeaderInfo(string[] infoList)
		{
			XmlDocument doc = new XmlDocument();
			XmlNode root = doc.CreateNode(XmlNodeType.Element, "","PageHeader",null);
			doc.AppendChild(root);
			XmlNode rt = doc.DocumentElement;
			string[] headers = {"StmtType","DateRequested","AcctName","AcctNumb","ProdNumb","ProdDescription","DateFrom","DateTo","PageSize","CustInfo"};
			for(int i=0; i<infoList.Length; i++)
			{
				rt.AppendChild(CreateXmlElement(doc,headers[i],infoList[i]));
			}
			return doc;
		}

		private static XmlElement CreateXmlElement(XmlDocument doc, string name, string val)
		{
			XmlElement node = doc.CreateElement(name);
			if(val != null)
				node.InnerText = val;
			return node;
		}

		public static string GetAccountStatement(string sAppID,string sChannelID,string sUserName,string sVersion,
			string sNZBAAccountNumber,DateTime datStart,DateTime datEnd,string sStartSequence,long lMaximumRowsToReturn,
			out XmlDocument sAccountStatementXml,out string sNextStartSequence)
		{
			const string ERR_IRD_TAS_NOT_AVAILABLE = "40012";
			sAccountStatementXml = new XmlDocument();
			InteropStatement oBPAcctStmt = new InteropStatement();
			string sResult = string.Empty;
			string sxml = string.Empty;
            
            sResult = oBPAcctStmt.GetAccountStatement(sAppID, sChannelID, sUserName, sVersion, sNZBAAccountNumber, datStart, datEnd, sStartSequence, (int)lMaximumRowsToReturn, out sxml, out sNextStartSequence);

			if(sResult != Constants.SUCCESS)
				return sResult;
			
			if(sxml != "")
			{
				XmlDocument tranAcct = new XmlDocument();
				tranAcct.LoadXml(sxml);
				XmlNode root = tranAcct.DocumentElement;
				XmlNodeList trans = root.SelectNodes("/data/Tran");

				if(trans.Count == 0)
					throw new Exception("NO_TRANSACTION_AVAILABLE",null);
                if (trans.Count > MAX_RECORS_RETURNED && sChannelID == Utility.Constants.FASTNETC)
                    throw new Exception("NumberOfRecordsReturnedMoreThanMax", null);
			}

			if(sResult == ERR_IRD_TAS_NOT_AVAILABLE)
			{
				sxml = "";
				return sResult;
			}
			
			sAccountStatementXml.LoadXml(sxml);
			return sResult;

		}

		private static string GetCCAccountStatement(string sCreditCardNumb,DateTime datStart, DateTime datEnd, string sStartSequence, bool bForExport, out XmlDocument sStatementXml, out string sNextStartSequence, string sChannelID)
		{
			const int MAX_STATEMENT_NO = 7;
			const int STATEMENT_REQUESTED_NOT_FOUND = 10;

			string sResult = Constants.SUCCESS;
			int iFirstStatement, iLastStatement, iStatementNumb;
			string iPeriod0StartDate = string.Empty;
			bool bHasError;
			bool bHasData;
			int lResultErrNo = 0;

			//This two value is everything I need from this method
			sStatementXml = new XmlDocument();
			sNextStartSequence = string.Empty;

			string sXml = string.Empty;
			string sMoreXml = string.Empty;
			string sZeroXml = string.Empty;

			Hashtable cacheData = new Hashtable();
			if(sStartSequence == "")
			{
				iFirstStatement = -1;
				iLastStatement = -1;
				iStatementNumb = 0;
				bHasData = false;

				DateTime openDate = DateTime.MaxValue;
				DateTime closeDate = DateTime.MaxValue;

				while(iStatementNumb <= MAX_STATEMENT_NO)
				{
					sXml = string.Empty;
					sResult = FetchCCStmt(sCreditCardNumb, true,iStatementNumb,ref iPeriod0StartDate,ref cacheData, out sXml,out bHasError, sChannelID);

					if(bHasError && !bHasData)
						return sResult;
					if(sResult == Constants.SUCCESS)
					{
						bHasData = true;
						XmlDocument doc = new XmlDocument();
						doc.LoadXml(sXml);
						XmlNode startNode = doc.SelectSingleNode("/xml/CCHDR/AccountOpenDate");
						XmlNode endNode = doc.SelectSingleNode("/xml/CCHDR/ClosingDate");
						openDate = DateTime.Parse(startNode.InnerText);
						if(endNode.InnerText != "")
							closeDate = DateTime.Parse(endNode.InnerText);
						if((endNode.InnerText == "" && datEnd >= openDate) || (openDate <= datEnd && datEnd <= closeDate) || (datStart <= closeDate && closeDate <= datEnd))
						{
							iLastStatement = iStatementNumb;
							break;
						}
						if(datStart >= openDate)
                            break;
					}
					else
					{
						iLastStatement = iStatementNumb;
					}
					iStatementNumb = iStatementNumb + 1;
				}

				if(iLastStatement != -1)
				{
					do
					{
						iFirstStatement = iStatementNumb;

						if(sResult == Constants.SUCCESS)
						{
							if(openDate <= datStart)
							{
								if(openDate <=datStart && closeDate < datStart)
									iFirstStatement = iFirstStatement -1;
								break;
							}
						}
						iStatementNumb = iStatementNumb + 1;

						if(iStatementNumb <= MAX_STATEMENT_NO)
						{
							sXml = string.Empty;
							sResult = FetchCCStmt(sCreditCardNumb, true,iStatementNumb,ref iPeriod0StartDate,ref cacheData, out sXml,out bHasError, sChannelID);

							if(sResult != Constants.SUCCESS)
							{
								//TODO: Process the ASB Error Handler
								XmlDocument doc = new XmlDocument();
								doc.LoadXml(sResult);
								lResultErrNo = int.Parse(doc.SelectSingleNode("/Error/Code").InnerText);

								if(bHasError && !bHasData)
									return sResult;

								if(lResultErrNo != STATEMENT_REQUESTED_NOT_FOUND)
									break;
							}
							//get the new opendate and closedate
							if(sXml != "")
							{
								XmlDocument xdoc = new XmlDocument();
								xdoc.LoadXml(sXml);
								XmlNode startNode = xdoc.SelectSingleNode("/xml/CCHDR/AccountOpenDate");
								XmlNode endNode = xdoc.SelectSingleNode("/xml/CCHDR/ClosingDate");
								openDate = DateTime.Parse(startNode.InnerText);
								if(endNode.InnerText != "")
									closeDate = DateTime.Parse(endNode.InnerText);
							}
							
						}

					}while(iStatementNumb <= MAX_STATEMENT_NO);
				}
				//TODO: Raise error when REQUEST NOT FOUND
				if(sResult != Constants.SUCCESS && lResultErrNo != STATEMENT_REQUESTED_NOT_FOUND)
					return sResult;

				if(iLastStatement == -1)
				{
					throw new Exception("NO_TRANSACTION_AVAILABLE",null);
				}
				iStatementNumb = iFirstStatement;
			}
			else
			{
				bHasData = true;
				string[] splitSequence = sStartSequence.Split('|');
				sCreditCardNumb = splitSequence[0];
				datStart = DateTime.Parse(splitSequence[1]);
				datEnd = DateTime.Parse(splitSequence[2]);
				iFirstStatement = int.Parse(splitSequence[3]);
				iLastStatement = int.Parse(splitSequence[4]);
				iStatementNumb = int.Parse(splitSequence[5]);
				iPeriod0StartDate = splitSequence[6];
			}

			if(sResult == Constants.SUCCESS || lResultErrNo == STATEMENT_REQUESTED_NOT_FOUND)
			{
				sResult = string.Empty;
				while(sResult != Constants.SUCCESS && iStatementNumb >= iLastStatement)
				{
					sXml = string.Empty;
					sResult = FetchCCStmt(sCreditCardNumb, false,iStatementNumb,ref iPeriod0StartDate,ref cacheData, out sXml,out bHasError, sChannelID);

					if (sResult == Constants.SUCCESS)
						bHasData = true;
					else
					{
						if (bHasError && !bHasData)
							return sResult;
					}
					iStatementNumb = iStatementNumb - 1;
				}

				iStatementNumb = iStatementNumb + 1;

				if (bForExport) //always true in this case
				{
					while (iStatementNumb > iLastStatement)
					{
						if (iStatementNumb == iLastStatement)
							break;

						iStatementNumb = iStatementNumb - 1;

						sResult = FetchCCStmt(sCreditCardNumb, false, iStatementNumb, ref iPeriod0StartDate, ref cacheData, out sMoreXml, out bHasError, sChannelID);

						if (sResult != Constants.SUCCESS)
						{
							if (bHasError && !bHasData)
								return sResult;
						}
						else
						{
							bHasData = true;
							XmlDocument target = StringToXML(sXml);
							XmlDocument source = StringToXML(sMoreXml);
							XmlNode root = target.DocumentElement;
							XmlNode sroot = source.DocumentElement;
							XmlNodeList sourceBody = sroot.SelectNodes("/xml/CCSTD");
							XmlNode fTargetContent = root.LastChild;
							XmlNode sourceHead = target.ImportNode(sroot.FirstChild,true);// CopyNodeToDestinationDocument(target,sroot.FirstChild,"CCHDR");

							// append header
							root.InsertBefore(sourceHead,root.FirstChild);
							//append body
							for(int i = sourceBody.Count-1;i>=0;i--)
							{
								XmlNode var = sourceBody[i];
								root.InsertAfter(target.ImportNode(var,true),fTargetContent);//CopyNodeToDestinationDocument(target,var,"CCSTD")
							}
							sXml = target.OuterXml;
						}
					}

					if (iLastStatement != 0 && sResult == Constants.SUCCESS)
					{
						sResult = FetchCCStmt(sCreditCardNumb, true, 0, ref iPeriod0StartDate,ref cacheData, out sZeroXml, out bHasError, sChannelID);

						if (sResult != Constants.SUCCESS)
						{
							if (bHasError && !bHasData)
							{
								return sResult;
							}
						}
						else
						{
							bHasData = true;
							XmlDocument target = StringToXML(sXml);
							XmlNode root = target.DocumentElement;
							XmlDocument zeroDoc = StringToXML(sZeroXml);
							XmlNode zeroHead = zeroDoc.SelectSingleNode("/xml/CCHDR");
							XmlNode header = target.ImportNode(zeroHead,true); // CopyNodeToDestinationDocument(target,zeroHead,"CCHDR");
							root.InsertBefore(header,root.FirstChild);

							sXml = target.OuterXml;
						}
					}
				}
			}

			if (sResult == Constants.SUCCESS)
			{
				XmlDocument resultDoc = new XmlDocument();
				resultDoc.LoadXml(sXml);
				XmlNode root = resultDoc.DocumentElement;
				XmlNodeList listDetail = root.SelectNodes("/xml/CCSTD");
				foreach(XmlNode var in listDetail)
				{
					if(var["ValueDate"].InnerText != "")
					{					
						DateTime processDate = DateTime.Parse(var["ValueDate"].InnerText);

						if(processDate < datStart ||processDate > datEnd)
							root.RemoveChild(var);
					}

				}
				if(root.SelectNodes("/xml/CCSTD").Count == 0)
					throw new Exception("NO_TRANSACTION_AVAILABLE");
				if(iStatementNumb != iLastStatement)
				{
					sNextStartSequence = sCreditCardNumb +"|"+ datStart.ToString("dd-MMM-yyyy") + "|" + datEnd.ToString("dd-MMM-yyyy") + "|" + iFirstStatement.ToString() + "|" + iLastStatement.ToString() + "|" + (iStatementNumb-1)+"|" + iPeriod0StartDate;
				}
				else
					sNextStartSequence = "";

				sStatementXml = resultDoc;

			}
			cacheData.Clear();
			return sResult;
		}

		//		private static XmlNode CopyNodeToDestinationDocument(XmlDocument doc, XmlNode node, string name)
		//		{
		//			string source = node.InnerXml;
		//			XmlNode result = doc.CreateNode( XmlNodeType.Element,name,"");
		//			result.InnerXml = source;
		//			return result;
		//		}
		private static XmlDocument StringToXML(string xml)
		{
			XmlDocument doc = new XmlDocument();
			doc.LoadXml(xml);
			return doc;
		}
		private static string FetchCCStmt(string sCreditCardNumb, bool bRetrieveMinimumDetails, int iStatementNumb, ref string iPeriod0StartDate, ref Hashtable cacheData, out string sxml, out bool bHasError, string sChannelID)
		{

			string sInSequence = "";
			string sOutSequence = "";
			string sResult = Constants.SUCCESS;
			string sZeroXml = string.Empty;
			sxml = string.Empty;
			string sMore = string.Empty;
			bHasError = false;
			bool bFetchMore = false;
			CreditCardInfo ccInfo;

			string key = sCreditCardNumb + iStatementNumb.ToString();

			if(cacheData.ContainsKey(key))
			{
				ccInfo = (CreditCardInfo)cacheData[key];
				sxml = ccInfo.sxml;
				sMore = ccInfo.sSequence;
				if(iStatementNumb == 0 && bRetrieveMinimumDetails)
				{
					sResult = GetCCStatement(sChannelID,sCreditCardNumb,0,"",1,ref iPeriod0StartDate,ref sZeroXml,out sOutSequence, out bHasError);
					if(sResult != Constants.SUCCESS)
					{
						sxml = string.Empty;
						if(bHasError)
							return sResult;
					}
					else
					{
						XmlDocument sdoc = new XmlDocument();
						sdoc.LoadXml(sxml);
						XmlDocument ccdoc = new XmlDocument();
						ccdoc.LoadXml(sZeroXml);
						XmlNode sNode = sdoc.SelectSingleNode("/xml/CCHDR/AccountOpenDate");
						XmlNode ccNode = ccdoc.SelectSingleNode("/xml/CCHDR/AccountOpenDate");
						if(sNode.InnerText != ccNode.InnerText)
							cacheData = new Hashtable();
						sxml = sZeroXml;
						sMore = sOutSequence;
					}
				}

				if(sResult == Constants.SUCCESS)
				{
					if(bRetrieveMinimumDetails || sMore == string.Empty || sMore == null)
					{}
					else
					{
						bFetchMore = true;
						sInSequence = sMore;
					}

					if(iStatementNumb == 0 && bRetrieveMinimumDetails)
					{
						CreditCardInfo info = new CreditCardInfo(sxml,sOutSequence);
						if(!cacheData.ContainsKey(key))
							cacheData.Add(key,info);
					}
				}
			}
			else
				bFetchMore = true;

			if(bFetchMore && sResult== Constants.SUCCESS)
			{
				int minRows = 1;
				if(!bRetrieveMinimumDetails)
					minRows = 1000;

				sResult = GetCCStatement(sChannelID,sCreditCardNumb,iStatementNumb,sInSequence,minRows, ref iPeriod0StartDate,ref sxml,out sOutSequence,out bHasError);

				if(sResult != Constants.SUCCESS)
					return sResult;
				else
				{
					CreditCardInfo info = new CreditCardInfo(sxml,sOutSequence);
					if(cacheData.ContainsKey(key))
						cacheData.Remove(key);
					cacheData.Add(key,info);
				}
			}
			return sResult;
		}
		private static string GetCCStatement(string sAppID, string sCCNumb,int iStatementNumb, string sStartSequence, int iMinimumRows, ref string iPeriod0StartDate, ref string isStatementXml, out string sNextStartSequence, out bool bHasError)
		{
			string sResult = string.Empty;
			int iBankNumber;
			string sStatementXml = string.Empty;
			bHasError = false;
			DateTime statementMonth;
			InteropStatement oBPAcctStmt = new InteropStatement();
			if(sAppID == "FASTNETC")
				iBankNumber = 12;
			else
				iBankNumber = 21;

			int monthYearNumber = 0;
			iPeriod0StartDate = string.Empty;
			if(iStatementNumb > 0)
			{
				if(iPeriod0StartDate == "")
				{
					sResult = oBPAcctStmt.GetCreditCardStatement(sAppID,iBankNumber,sCCNumb,0,"",1,out sStatementXml,out sNextStartSequence);
					if(iPeriod0StartDate == "")
						iPeriod0StartDate = ReadXmlNode(sStatementXml,"CCHDR/AccountOpenDate");
					else
						iPeriod0StartDate = DateTime.Now.ToString();
				}
				statementMonth = DateTime.Parse(iPeriod0StartDate).AddMonths(-1*(iStatementNumb-1));

				monthYearNumber = statementMonth.Month * 100 + statementMonth.Year % 100;
			}

			sResult = oBPAcctStmt.GetCreditCardStatement(sAppID, iBankNumber,sCCNumb,monthYearNumber,sStartSequence,iMinimumRows, out sStatementXml, out sNextStartSequence);


			if(sResult != Constants.SUCCESS)
			{
				//				//TODO: deal with error message
				//				if(ReadXmlNode(sResult,"Code") == "10")
				//					sResult = "| 1|9210|Statement requested not found|10 Statement requested not found|Tran_DCCST.BuildCreditCardStatement|HOST|BUS|@|";
				//				else if (ReadXmlNode(sResult,"Code") == "90")
				//					sResult = "| 1|9291|Invalid Input|90 Invalid Input|Tran_DCCST.BuildCreditCardStatement|HOST|BUS|@|";
				//				else if (ReadXmlNode(sResult,"Code") == "91")
				//					sResult = "| 1|9291|Invalid Input|91 Invalid Input|Tran_DCCST.BuildCreditCardStatement|HOST|BUS|@|";
				//				else if (ReadXmlNode(sResult,"Code") == "92")
				//					sResult = "| 1|9292|Card Number is invalid|92 Card Number is invalid|Tran_DCCST.BuildCreditCardStatement|HOST|BUS|@|";
				//				else
				//					sResult = "| 1|1031|The host is currently off-line||Transaction Manager|TM|CRIT|@|";
				//				
				bHasError = true;
				isStatementXml = string.Empty;
				return sResult;
			}
			else
			{
				if(iStatementNumb == 0 && sStartSequence == "")
					iPeriod0StartDate = ReadXmlNode (sStatementXml,"CCHDR/AccountOpenDate");

				XmlDocument doc = new XmlDocument();
				doc.LoadXml(sStatementXml);
				XmlNode root = doc.DocumentElement;
				XmlNode openBalNode = root.SelectSingleNode("/xml/CCSTD");
				XmlNode node = root.SelectSingleNode("/xml/CCSTD/ValueDate");
				
				if(openBalNode != null)
					if(node != null)
						if(node.InnerText == "")
							root.RemoveChild(openBalNode);

				XmlNode recordNode = root.SelectSingleNode("/xml/CCHDR");
				if(recordNode != null)
				{
					XmlNode cNode = doc.CreateNode(XmlNodeType.Element,"StatementNumber",null);
					cNode.InnerText = iStatementNumb.ToString();
					recordNode.InsertBefore(cNode,recordNode.FirstChild);
				}
				//append new records
				if(isStatementXml != "")
				{
					XmlDocument inputStmt = new XmlDocument();
					inputStmt.LoadXml(isStatementXml);
					XmlNode inputStmtRoot = inputStmt.DocumentElement;

					XmlNodeList stdNodeList = inputStmtRoot.SelectNodes("/xml/CCSTD");
					XmlNode lastNode = stdNodeList[stdNodeList.Count-1];

					XmlNodeList appendList = doc.SelectNodes("/xml/CCSTD");
					foreach(XmlNode var in appendList)
					{
						XmlNode iNode = inputStmt.ImportNode(var,true);
						inputStmtRoot.InsertAfter(iNode,lastNode);
						lastNode = iNode;
					}
					isStatementXml = inputStmt.OuterXml;
				}
				else
					isStatementXml = doc.OuterXml;
			}
			return sResult;
		}


		private static string ReadXmlNode(string inputXml, string sectionNode)
		{
			if(inputXml == "")
				return "";
			XmlDocument doc = new XmlDocument();
			doc.LoadXml(inputXml);
			string xpathExpr = "/" + doc.DocumentElement.Name + "/"+sectionNode;
			XmlNode node = doc.SelectSingleNode(xpathExpr);
			if(node != null)
				return node.InnerText;
			else
				return "";
		}

		#region Personalised Account Names Methods

		
		/// <summary>
		/// Gets all the accounts that are or can be personalised.  Sets the output parameter to be an
		/// array of PersonalisableAccount objects where each account has an array of PersonalisableAccountSuffix
		/// objects.
		/// </summary>
		public static string GetPersonalisableAccounts(string sessionGuid, string appID, string channelID, string hostUserName, string customerNumber, out PersonalisableAccount[] output)
		{									
			string result = string.Empty;
			int[] AllowedProdNumbs;
			string personalisableProductsXml;
			ASB.BC.Account.IAccount_2010_2 oAccount = null;			
			oAccount = new ASB.BC.Account.Account();
			result = oAccount.GetProductListForAttribute(appID, channelID, PROD_ATTRIBUTE_PERSONALISATION, out personalisableProductsXml);
			if (result != Constants.SUCCESS)
			{
				output = null;
				return result;
			}
			XmlDocument oDoc = new XmlDocument();
			oDoc.LoadXml(personalisableProductsXml);
			XmlNodeList oNodeList;
			oNodeList = oDoc.SelectNodes("/productListForAttribute/productForAttribute");
			ArrayList personalisableProducts = new ArrayList();			
			
			foreach(XmlNode oNode in oNodeList)
			{
				try
				{
					int productId = int.Parse(oNode.SelectSingleNode("productId").InnerText);	
					personalisableProducts.Add(productId);
				}
				catch { }				
				
			}
			AllowedProdNumbs = (int[]) personalisableProducts.ToArray(typeof(int));

			// first get all the product XML
			string productsXml;
			result = GetProductsByCustomer(sessionGuid, appID, channelID, "12", customerNumber, hostUserName, out productsXml);
			if (result != Constants.SUCCESS)
			{
				output = null;
				return result;
			}

			// Now load it as an XML document, and create an arraylist of PersonalisableAccount objects
			// which each have an array of PersonalisableAccountSuffix objects.
			XmlDocument document = new XmlDocument();
			document.LoadXml(productsXml);
			ArrayList accounts = new ArrayList();

			// Each <Section_CPIA> node in the XML describes an account (without a suffix)
			foreach (XmlNode accountNode in document.SelectNodes("/TMResponse/Section_CPIA"))
			{
				PersonalisableAccount account = (PersonalisableAccount) XmlHelper.Inflate(accountNode.OuterXml, typeof(PersonalisableAccount));
				ArrayList suffixes = new ArrayList();

				// The suffixes are NOT children of the account node, but rather siblings of it.
				// Therefore, we browse through the siblings until we get to another Section_CPIA node.
                for (XmlNode siblingNode = accountNode.NextSibling; (siblingNode != null) && (siblingNode.LocalName != "Section_CPIA"); siblingNode = siblingNode.NextSibling)
                {
                    // only certain products in CPID are personalisable.
                    // Get the ProdNumb of the current account and if it's an allowed numb, add it to the list.	
                    int prodNumb = siblingNode.SelectSingleNode(".//ProdNumb") == null ? 0 : int.Parse(siblingNode.SelectSingleNode(".//ProdNumb").InnerText);
                    if (siblingNode.LocalName == "Section_CPID")
                    {
                        if (Array.IndexOf(AllowedProdNumbs, prodNumb) > -1)
                        {
                            PersonalisableAccountSuffix_CPID suffix = (PersonalisableAccountSuffix_CPID)XmlHelper.Inflate(siblingNode.OuterXml, typeof(PersonalisableAccountSuffix_CPID));
                            suffix.Account = account;
                            suffix.PersonalisedName = suffix.PersonalisedName.Trim();
                            suffixes.Add(suffix);
                        }
                    }
                    if (siblingNode.LocalName == "Section_CPII")
                    {
                        if (Array.IndexOf(AllowedProdNumbs, prodNumb) > -1)
                        {
                            PersonalisableAccountSuffix_CPII suffix = (PersonalisableAccountSuffix_CPII)XmlHelper.Inflate(siblingNode.OuterXml, typeof(PersonalisableAccountSuffix_CPII));
                            suffix.Account = account;
                            suffix.PersonalisedName = suffix.PersonalisedName.Trim();
                            suffixes.Add(suffix);
                        }
                    }
                }

				// If there were personalisable suffixes, then add them to the account reference, and
				// add the account to the list of accounts. Note that therefore only those accounts
				// with suffixes are returned.
				if (suffixes.Count > 0)
				{
					account.Suffixes = (PersonalisableAccountSuffix[]) suffixes.ToArray(typeof(PersonalisableAccountSuffix));
					accounts.Add(account);
				}
			}

			// set the output; return the result.
			output = (PersonalisableAccount[]) accounts.ToArray(typeof(PersonalisableAccount));
			return result;
		}


		/// <summary>
		/// Updates or deletes the personalised name of an account based on the value given in 
		/// the suffixToUpdate object.
		/// </summary>
		public static string UpdatePersonalisedAccountName(string sessionGuid, string appID, string channelID, string hostUserName, string customerNumber, PersonalisableAccountSuffix suffixToUpdate)
		{
			ASB.BC.Account.IAccount_2008_1 account = null;
			string result;
			try
			{
				account = new ASB.BC.Account.Account();
				bool deleteTextFlag = !suffixToUpdate.IsPersonalised;
				string personalisedName = suffixToUpdate.PersonalisedName.Trim();
				
				// call middleware to update the account name
				string xml = account.UpdatePersonalisedAcctName(appID, channelID, hostUserName, customerNumber, suffixToUpdate.FullNzbaAccountNumber, personalisedName, deleteTextFlag);
				
				if (xml != Constants.SUCCESS)
				{
					// The middleware call returns an error if you try to delete an already-deleted account
					// name.  This can happen in certain circumstances, and is harmless, so in these cases
					// the call is considered a success.
					XmlDocument document = new XmlDocument();
					document.LoadXml(xml);
					if (document.SelectSingleNode("/Errors/Error/TransactionName").InnerText == "ACT")
					{
						XmlNode node2 = document.SelectSingleNode("/Errors/Error/Number");
						try
						{
							if (int.Parse(node2.InnerText) == 9 /* Already-deleted-name error code */)
							{
								xml = Constants.SUCCESS;
							}
						} 
						catch { }
					}
				}
				result = xml;
			}
			finally
			{
				if (account != null)
				{
					ServicedComponent.DisposeObject((ServicedComponent) account);
				}
			}
			return result;
		}

		#endregion

		
		/// <summary>
		/// Calls ASB_BC_Account.IAccount_2008_2.OpenManagedFundAccount.
		/// Also flushes all the balances as they now have a new account.
		/// Returns newly created suffix as the out parameter.
		/// </summary>
		public static string OpenManagedFundAccount(string sSessionId, string sAppId,string sChannelId,
			string sHOST,string sStemNumber,string sProdCode,string sBankNumber,
			string sCustomerNumber, string sFromNZBAAccountNumber,
			decimal dTransferAmount, out string sSuffix, AuditLogDetails auditLogDetails)
		{

			string sResult;
			string sOutXml;
			string sAccountStem;
					
			ASB.BC.Account.IAccount_2008_2 oAccount = null; 
			sSuffix = "";
			sAccountStem = "";

			try
			{
				oAccount = new ASB.BC.Account.Account();
				sResult = oAccount.OpenManagedFundAccount(sAppId,sChannelId,sHOST,sStemNumber,sProdCode,
					dTransferAmount,sFromNZBAAccountNumber,
					sBankNumber,sCustomerNumber,out sOutXml);

				if (sResult == ASB.Utility.Common.Constants.SUCCESS)
				{
					
					#region example sOutXml
					//						<TMResponse>
					//							<TransactionName>903</TransactionName> 
					//							<ClientAppID>FASTNETC</ClientAppID> 
					//							<Section_U005>
					//								<ProductName>CASH FUND</ProductName> 
					//								<NzbaAcctUniqNumb>012302000100280</NzbaAcctUniqNumb> 
					//								<NzbaAcctSufxNumb>66</NzbaAcctSufxNumb> 
					//							</Section_U005>
					//							<Section_UPDATE>
					//								<UpdateInfoItem1>New CASH FUND account - suffix 66</UpdateInfoItem1> 
					//							</Section_UPDATE>
					//							<Section_Journal>
					//								<TelrTranNumb>504794</TelrTranNumb> 
					//								<HostTSN>00230337</HostTSN> 
					//								<Tanked>0</Tanked> 
					//							</Section_Journal>
					//						</TMResponse>
					#endregion

					//get the suffix for the newly opened cash fund account
					XmlDocument xmlDoc = new XmlDocument();
					xmlDoc.LoadXml(sOutXml);
 
					XmlNode xmlNode = xmlDoc.SelectSingleNode("/TMResponse/Section_U005/NzbaAcctSufxNumb");
					if (xmlNode != null) sSuffix = xmlNode.InnerText;

					xmlNode = xmlDoc.SelectSingleNode("/TMResponse/Section_U005/NzbaAcctUniqNumb");
					if (xmlNode != null) sAccountStem = xmlNode.InnerText; 

					if (!(sSuffix == "" || sAccountStem == "")) 
					{
						//flush balances as we now have a new account
						Flush(sSessionId);

						//do auditing
						Logging.AuditLog(auditLogDetails);     
					}
					else
					{
						sResult = "ASB.BC.Account.IAccount_2008_2.OpenManagedFundAccount returned empty NzbaAcctUniqNumb/NzbaAcctSufxNumb elements. Stem=" + sAccountStem + ",Suffix=" + sSuffix;
					}
					
				}
			}
			finally
			{
				if (oAccount != null)
					ServicedComponent.DisposeObject((ServicedComponent)oAccount);
			}

			return sResult;
		}

		public class ExportArgs
		{
			private readonly string _appID;
			private readonly string _channelID;
			private readonly string _accountName;
			private readonly string _accountNumber;
			private readonly string _accountType;
			private readonly string _productNumber;
			private readonly string _productDescription;
			private readonly DateTime _fromDate;
			private readonly DateTime _toDate;
			private readonly string _customInfo;
			private readonly string _sessionID;
			private readonly string _ipAddress;

			public ExportArgs(string appID, string channelID, string accountName, string accountNumber, string accountType, string productNumber, string productDescription, DateTime fromDate, DateTime toDate, string customInfo, 
				string sessionID, string ipAddress)
			{
				_appID = appID;
				_channelID = channelID;
				_accountName = accountName;
				_accountNumber = accountNumber;
				_accountType = accountType;
				_productNumber = productNumber;
				_productDescription = productDescription;
				_fromDate = fromDate;
				_toDate = toDate;
				_customInfo = customInfo;
				_sessionID = sessionID;
				_ipAddress = ipAddress;
			}

			public string AppID
			{
				get { return _appID; }
			}

			public string ChannelID
			{
				get { return _channelID; }
			}

			public string AccountName
			{
				get { return _accountName; }
			}

			public string AccountNumber
			{
				get { return _accountNumber; }
			}

			public string AccountType
			{
				get { return _accountType; }
			}

			public string ProductNumber
			{
				get { return _productNumber; }
			}

			public string ProductDescription
			{
				get { return _productDescription; }
			}

			public DateTime FromDate
			{
				get { return _fromDate; }
			}

			public DateTime ToDate
			{
				get { return _toDate; }
			}

			public string CustomInfo
			{
				get { return _customInfo; }
			}

			public string SessionID
			{
				get { return _sessionID; }
			}
			
			public string IpAddress
			{
				get { return _ipAddress; }
			}
		}

		public struct CreditCardInfo
		{
			public string sxml;
			public string sSequence;
			public CreditCardInfo(string sxml, string sSequence)
			{
				this.sxml = sxml;
				this.sSequence = sSequence;
			}
		}
		
		/// <summary>
		/// Checks if the user has accounts that can make Internation Money Transfers
		/// </summary>
		public static string CheckForIMTAccounts(string sSessionGUID, string sAppID,string sChannelID, string sCustomerNumber, out bool userHasNewZealandAccounts, out bool userHasForeignCurrencyAccounts)
		{
			userHasNewZealandAccounts = false; 
			userHasForeignCurrencyAccounts = false;
			string xml;
			string result = GetProductsByCustomer(sSessionGUID, sAppID,sChannelID, "12", sCustomerNumber, "", out xml);
			
			if (result != Constants.SUCCESS)
			{
				return result;
			}

			DataSet data = new DataSet();	
			data.ReadXml(new System.IO.StringReader(xml),System.Data.XmlReadMode.InferSchema);

			userHasNewZealandAccounts = data.Tables.Contains("Section_CPID");
			userHasForeignCurrencyAccounts = data.Tables.Contains("ForeignCurrencyAccount");

			return result;
		}

		/// <summary>
		/// Lists accounts that can be used to make International Money Transfers.
		/// </summary>
		public static string GetIMTAccounts(string sSessionGUID, string sAppID,string sChannelID, string sCustomerNumber, bool ExcludeNZDForeignCurrencyAccounts, bool ExcludeAccountsOnHold, out DataTable imtAccounts)
		{
			string xml;
			imtAccounts = null;
			string result = GetProductsByCustomer(sSessionGUID, sAppID,sChannelID, "12", sCustomerNumber, "", out xml);
			
			if (result == Constants.SUCCESS && xml != "")
			{
				DataSet data = new DataSet();	
				data.ReadXml(new System.IO.StringReader(xml),System.Data.XmlReadMode.InferSchema);

                // NOTE**************: The structure of this datatable should be the same as imtaccounts table in the method "ConstructFCADatatable" - FNC\FrontEnd\ForeignExchange\IMT\IMTFCARepository.cs 
                // Any changes to this should be also reflected in "ConstructFCADatatable

				imtAccounts = new DataTable("IMTAccounts");
				
				imtAccounts.Columns.Add("Name",System.Type.GetType("System.String"));
				imtAccounts.Columns.Add("Number",System.Type.GetType("System.String"));
				imtAccounts.Columns.Add("CurrencyCode",System.Type.GetType("System.String"));
				imtAccounts.Columns.Add("ProductNumber",System.Type.GetType("System.String"));
				imtAccounts.Columns.Add("AvailableBalance",System.Type.GetType("System.String"));
				imtAccounts.Columns.Add("AccountOnHold",System.Type.GetType("System.Boolean"));
                imtAccounts.Columns.Add("AcctHoldStatusCode", System.Type.GetType("System.String"));
				imtAccounts.Columns.Add("IsForeignCurrencyAccount",System.Type.GetType("System.Boolean"));
				imtAccounts.Columns.Add("IsPersonalEnterpriseOwner",System.Type.GetType("System.Boolean"));
				imtAccounts.Columns.Add("AcctStemName",System.Type.GetType("System.String"));


				DataTable dtCPIADetails;

				if (data.Tables.Contains("Section_CPID"))
				{
					dtCPIADetails = data.Tables["Section_CPIA"];
					foreach (DataRow depositAccount in data.Tables["Section_CPID"].Rows)
					{
						try
						{
							// Get the stem name and enterprise flag details for the nzbanumber from CPIA (parent) node.
							string acctUniqueNzbaNumb = depositAccount["AcctUniqueNzbaNumb"].ToString();
							dtCPIADetails.DefaultView.RowFilter = "AcctUniqueNzbaNumb = " + acctUniqueNzbaNumb;

							bool bIsPersonalEnterpriseOwner = dtCPIADetails.DefaultView[0]["PersonalEnterpriseOwnerFlag"].ToString().ToUpper() == "E";
							string acctStemName = dtCPIADetails.DefaultView[0]["AcctName"].ToString();
							

							string numberSignaturesRequired = depositAccount["SigtReqd"].ToString();
							if (numberSignaturesRequired != "1")
								continue;

							string name;

							if (depositAccount["AcctPersonalisedName"].ToString().Trim().Length > 0)
								name = depositAccount["AcctPersonalisedName"].ToString();
							else
								name = FormatNZBAAccountNumber(depositAccount["AcctUniqueNzbaNumb"].ToString(), depositAccount["AcctSufxNzbaNumb"].ToString());							

							string number = depositAccount["AcctUniqueNzbaNumb"].ToString() + depositAccount["AcctSufxNzbaNumb"].ToString();
							string currencyCode = "NZD";
							string productNumber = depositAccount["ProdNumb"].ToString();
							decimal availableBalance = decimal.Parse(depositAccount["AcctAvailableBalAmt"].ToString())/100;
							bool accountOnHold = int.Parse(depositAccount["AcctClosedFlag"].ToString()) == 1;
							System.Diagnostics.Debug.WriteLine(number + ":" + currencyCode  + ":" + productNumber  + ":" + availableBalance  + ":" + accountOnHold.ToString());
							if (! TransferAccount(int.Parse(depositAccount["ProdAttributes"].ToString()) ) )
								continue;

							if (accountOnHold && ExcludeAccountsOnHold)
								continue;

                            imtAccounts.Rows.Add(new object[] { name, number, currencyCode, productNumber, availableBalance, accountOnHold, "", false, bIsPersonalEnterpriseOwner, acctStemName });
						}
						catch(Exception e)
						{
							imtAccounts = null;
							return "FNC.BP.Balance.GetIMTAccounts error parsing accounts data: " + e.Message;
						}
					}
				}
			}

			return result;
		}
	 
		public static string GetUniqueNumbers(string appID, string channelID, string hostUser,int bankNumber,string customerNumber,bool optAllUniqueNumbers, bool optEnquireInvestment,out string resultXml)
		{
			ASB.BC.Customer.ICustomer_2009_3 oCustomer = null;
			
			try
			{
				oCustomer = new ASB.BC.Customer.Customer();
				return oCustomer.GetUniqueNumbers(appID,channelID,hostUser,bankNumber,customerNumber,optAllUniqueNumbers,optEnquireInvestment,out resultXml);
			}
			finally
			{
				if (oCustomer != null)
					ServicedComponent.DisposeObject((ServicedComponent)oCustomer);
			}
		}

		public static string GetAutoPaymentLoanAuthorityDetail(string appID,string channelID,string hostUserName,string accountNumber,string paymentNumber,out string resultXml)
		{
			ASB.BC.Account.IPayment_2005_2 oAccount = null;

			try
			{
				oAccount = new ASB.BC.Account.Payment();
				return oAccount.GetAutoPaymentLoanAuthorityDetail(appID,channelID,hostUserName,accountNumber,paymentNumber,out resultXml);				
			}
			finally
			{
				if (oAccount != null)
					ServicedComponent.DisposeObject((ServicedComponent)oAccount);
			}
		}


		private static bool IsSecondTierCurrency(string sCurrencyCode)
		{
			string sResult, resultXml;
			ASB.BC.Account.ITreasury_2008_4 oTreasury = null;
			
			try
			{
				oTreasury = new ASB.BC.Account.Treasury();
				sResult = oTreasury.GetTierCurrencies(2, out resultXml);
				if(sResult == Constants.SUCCESS)
				{
					XmlDocument dom = new XmlDocument();
					dom.LoadXml(resultXml);
					if(dom.SelectSingleNode("Currencies[Currency='" + sCurrencyCode + "']") != null )
						return true;
					else
						return false;
				}
				else
					return false;
			}
			finally
			{
				if (oTreasury != null)
					ServicedComponent.DisposeObject((ServicedComponent)oTreasury);
			}			
		}

		private static bool NewZealandDollarForeignCurrencyAccount(string currencyCode)
		{
			if (currencyCode.ToUpper() == "NZD")
				return true;
			else
				return false;
		}
		private static string FormatNZBAAccountNumber(string stem, string suffix)
		{
			if ((stem.Length < 13) || ((suffix.Length -2) < 1))
				return stem + "-" + suffix;

			return	stem.Substring(1,2) + "-" +  
				stem.Substring(3,4) + "-" +  
				stem.Substring(8,7) + "-" + 
				suffix.Substring(suffix.Length - 2,2);
		}
		private static bool TransferAccount(int productAttributes)
		{
			if  ( (productAttributes & ((int)AsbRecordSetConstants.ASBPROD_ATTR_ProductAttributes.ASBPROD_ATTR_SEND_TRANSFER_FUNDS)) == 0 )
				return false;
			else
				return true;
		}
		private static bool IsNZDForeignCurrencyAccount(string productNumber)
		{
			if ((productNumber == "3914") || (productNumber == "3914")) 
			{
				return true;
			}
			return false;
		}

		/// <summary>
		/// Excludes Term Deposits and optionally Securities Accounts
		/// </summary>
		/// <param name="productNumber">Product Number to check</param>
		/// <param name="excludeSecuritiesAccounts">True if securities accounts should be excluded</param>
		/// <returns>True if product number is valid, false otherwise</returns>
		private static bool ProductIsValidForIMTTransfers(string productNumber, bool excludeSecuritiesAccounts)
		{
			// Exclude Term Deposits
			if (productNumber == PROD_FCA_ASBSEC_TERM_DEP || productNumber == PROD_FCA_TREASURY_TERM_DEP)
				return false;
			
			// Exclude Securities Accounts.
			if (excludeSecuritiesAccounts && productNumber == PROD_FCA_ASBSEC_CALL_DEP)
				return false;

			return true;
		}


		#region CPI Xml Helper

		internal static XmlNodeList ExtractCreditCardsFromCPIExcludeTrueReward(XmlDocument oCPIDoc, bool bIsTrueRewardsJoin, bool excludeClosedCC)
		{
			//Remove any Low Interest MasterCards and Visa Business
            if (bIsTrueRewardsJoin)
            {
                string sTrueRewardsXPathQuery = "";
                if (excludeClosedCC)
                    sTrueRewardsXPathQuery = "//Section_CPIC[ProdNumb != '" + VISABUSINESS_PRODUCT_CODE + "' and not(starts-with(CrCardNumb, '5000512')) and (AccountStatus='')]";
                else
                    sTrueRewardsXPathQuery = "//Section_CPIC[ProdNumb != '" + VISABUSINESS_PRODUCT_CODE + "' and not(starts-with(CrCardNumb, '5000512'))]";
                    
                return oCPIDoc.SelectNodes(sTrueRewardsXPathQuery);
            }
            else
            {
                if (excludeClosedCC)
                    return oCPIDoc.SelectNodes("//Section_CPIC[not(starts-with(CrCardNumb, '5000512')) and (AccountStatus='')]");
                return oCPIDoc.SelectNodes("//Section_CPIC[not(starts-with(CrCardNumb, '5000512'))]");
            }
			
		}
		internal static XmlNodeList ExtractTermLoansFromCPI(XmlDocument oCPIDoc)
		{
			return ExtractTermLoansFromCPI(oCPIDoc, null);
		}
		internal static XmlNodeList ExtractTermLoansFromCPI(XmlDocument oCPIDoc, string filteredByUniqueAccoutNumber)
		{
			return ExtraSectionFromCPI(oCPIDoc, CPIConstants.Section_CPIL, filteredByUniqueAccoutNumber);
		}
		internal static XmlNodeList ExtractCPIDsFromCPI(XmlDocument oCPIDoc)
		{
			return ExtractCPIDsFromCPI(oCPIDoc, null);
		}

		internal static XmlNodeList ExtractCPIDsFromCPI(XmlDocument oCPIDoc, string filteredByUniqueAccoutNumber)
		{
			return ExtraSectionFromCPI(oCPIDoc, CPIConstants.Section_CPID, filteredByUniqueAccoutNumber);
		}

		internal static XmlNodeList ExtractCPIIsFromCPI(XmlDocument oCPIDoc, string filteredByUniqueAccoutNumber)
		{
			return ExtraSectionFromCPI(oCPIDoc, CPIConstants.Section_CPII, filteredByUniqueAccoutNumber);
		}

		private static XmlNodeList ExtraSectionFromCPI(XmlDocument oCPIDoc, string filteredByElementName, string filteredByUniqueAccoutNumber)
		{
			string nodeFilter;

			//it's expected filteredByElementName is set
			if (filteredByElementName == null || filteredByElementName == string.Empty)
				return null;

			else if (filteredByUniqueAccoutNumber == null || filteredByUniqueAccoutNumber == string.Empty)
				nodeFilter = string.Format("//{0}", filteredByElementName);
			else
				nodeFilter = string.Format("//{0}[AcctUniqueNzbaNumb='{1}']", filteredByElementName, filteredByUniqueAccoutNumber);

			return oCPIDoc.SelectNodes(nodeFilter);
		}


		#endregion

		#region CPI Constants 

		/// <summary>
		/// Xml Node name as returned from CPI Call
		/// </summary>
		internal class CPIConstants
		{
			//Section_CPIC
			public const string Section_CPIC = "Section_CPIC";
			public const string CrCardNumb = "CrCardNumb";
			public const string CrCardLedgerBalAmt = "CrCardLedgerBalAmt";
			public const string CrCardAvailableBalAmt = "CrCardAvailableBalAmt";

			//Section_CPIL specific
			public const string Section_CPIL = "Section_CPIL";
			public const string LoanPaytNumb = "LoanPaytNumb";
		
			//Section_CPID specific
			public const string Section_CPID = "Section_CPID";
			public const string AcctPersonalisedName = "AcctPersonalisedName";
			public const string AcctOvdtLimitFormalAmt = "AcctOvdtLimitFormalAmt";

			//Section_CPII specific
			public const string Section_CPII = "Section_CPII";

			//common
			public const string AcctUniqueNzbaNumb = "AcctUniqueNzbaNumb";
			public const string AcctSufxNzbaNumb = "AcctSufxNzbaNumb";		
			public const string AcctLedgerBalAmt = "AcctLedgerBalAmt";
			public const string ProdNumb = "ProdNumb"; 
			public const string ProdDescription = "ProdDescription";
			
		}
		#endregion


	}
}
