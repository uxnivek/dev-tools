using System;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Serialization;

namespace ASBBank.FNC.BP.Balance
{


	/// <summary>
	/// An account containing suffixes which can be given personalised names.
	/// </summary>
	[Serializable]
	[XmlRoot("Section_CPIA")]
	public class PersonalisableAccount 
	{

		#region Fields
		private string _accountName;
		private string _nzbaNumber;
		private PersonalisableAccountSuffix[] _suffixes;
		#endregion

		#region Properties
		
		/// <summary>
		/// The (non-personalisable) name of the account, usually a person's name.
		/// </summary>
		[XmlElement("AcctName")]
		public string AccountName
		{
			get { return _accountName;}
			set { _accountName = value; }
		}

		/// <summary>
		/// The account stem number (i.e. without a suffix) in NZBA format, e.g. "012308600123573".
		/// </summary>
		[XmlElement("AcctUniqueNzbaNumb")]
		public string NzbaNumber
		{
			get { return _nzbaNumber;}
			set { _nzbaNumber = value; }
		}

		/// <summary>
		/// The suffixes in this account which can be given personalised names.
		/// </summary>
		public PersonalisableAccountSuffix[] Suffixes
		{
			get { return _suffixes;}
			set { _suffixes = value; }
		}

		#endregion

		#region Methods

		/// <summary>
		/// Sets the <see cref="PersonalisableAccountSuffix.Account" /> property for each suffix in
		/// the given accounts, as this property will be null after a <see cref="PersonalisableAccount" />
		/// object has been serialised.
		/// </summary>
		/// <remarks>
		/// PersonalisableAccount has an array of PersonalisableAccountSuffix objects, and each suffix
		/// in turn refers to its PersonalisableAccount.  This is a circular reference, which is not
		/// allowed during serialisation.  Therefore, the PersonalisableAccountSuffix.Account field is
		/// not serialised, and so after deserialisation, it is null.  Therefore, this method should
		/// be called after deserialisation in order to correctly set the PersonalisableAccountSuffix.Account
		/// property.
		/// </remarks>
		public static void SetSuffixAccountReferences(System.Collections.IEnumerable accounts) 
		{
			foreach(PersonalisableAccount account in accounts) 
			{
				foreach(PersonalisableAccountSuffix suffix in account.Suffixes) 
				{
					suffix.Account = account;
				}
			}
		}

		#endregion

	}

	[Serializable]
	public class PersonalisableAccountSuffix
	{		
		public const int MaximumNameLength = 18;		
		private const string ValidAccountNamePattern = "^[A-Za-z0-9 ]{0,18}$";
		
		protected int _suffix;
		protected string _accountTypeName;
		protected string _personalisedName;
		protected string _originalPersonalisedName = null;
		protected bool _hasBeenModified;
		protected PersonalisableAccount _account;

		#region Properties

		[XmlElement("AcctSufxNzbaNumb")]
		public virtual int Suffix
		{
			get { return _suffix; }
			set { _suffix = value; }
		}

		[XmlElement("ProdDescription")]
		public virtual string AccountTypeName
		{
			get { return _accountTypeName; }
			set { _accountTypeName = value; }
		}

		[XmlElement("AcctPersonalisedName")]
		public virtual string PersonalisedName
		{
			get { return _personalisedName; }
			set { _personalisedName = value; }
		}

		/// <summary>
		/// Gets the original name of this account suffix when <see cref="HasBeenModified" /> is true.
		/// This will be null if the user has not modified the account name since last saving.
		/// </summary>
		public string OriginalPersonalisedName
		{
			get;set;
		}
		
		public PersonalisableAccount Account
		{
			get { return _account; }
			set { _account = value; }
		}

		/// <summary>
		/// Gets whether or not this suffix's name has been personalised.
		/// </summary>
		public bool IsPersonalised
		{
			get { return _personalisedName != null && _personalisedName.Length > 0; }
		}

		/// <summary>
		/// Gets or sets whether or not this suffix has been modified by the user, but has not
		/// been saved to the datastore yet.
		/// </summary>
		public bool HasBeenModified
		{
			get { return _hasBeenModified; }
			set { _hasBeenModified = value; }
		}

		/// <summary>
		/// Gets the full account number (stem plus 4-digit suffix) in NZBA format, e.g. "0123086001235730051".
		/// </summary>
		public string FullNzbaAccountNumber
		{
			get { return _account.NzbaNumber + _suffix.ToString("0000"); }
		}
		#endregion
	
		public static bool IsValidAccountName(string name)
		{
			Regex validNameRegex = new Regex(ValidAccountNamePattern);
			if (validNameRegex.IsMatch(name))
			{
				return true;
			}
			else
			{
				return false;
			}
		}	
	}

	[Serializable]
	[XmlRoot("Section_CPID")]
	public class PersonalisableAccountSuffix_CPID : PersonalisableAccountSuffix
	{
	
		[XmlElement("AcctSufxNzbaNumb")]
		public override int Suffix
		{
			get { return _suffix; }
			set { _suffix = value; }
		}
		
		[XmlElement("ProdDescription")]
		public override string AccountTypeName
		{
			get { return _accountTypeName; }
			set { _accountTypeName = value; }
		}
		
		[XmlElement("AcctPersonalisedName")]
		public override string PersonalisedName
		{
			get { return _personalisedName; }
			set { _personalisedName = value; }
		}
	}

	[Serializable]
	[XmlRoot("Section_CPII")]
	public class PersonalisableAccountSuffix_CPII : PersonalisableAccountSuffix
	{		
		[XmlElement("AcctSufxNzbaNumb")]
		public override int Suffix
		{
			get { return _suffix; }
			set { _suffix = value; }
		}

		[XmlElement("ProdDescription")]
		public override string AccountTypeName
		{
			get { return _accountTypeName; }
			set { _accountTypeName = value; }
		}
		
		[XmlElement("AcctPersonalisedName")]
		public override string PersonalisedName
		{
			get { return _personalisedName; }
			set { _personalisedName = value; }
		}	

	}

}
