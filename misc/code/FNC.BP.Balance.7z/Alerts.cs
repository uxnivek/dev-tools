using System;
using System.Data;
using ASB.BC.Customer;
using ASB.CBO.Utility;
using ASB.Utility.Common;
using System.Collections;
using System.EnterpriseServices;
using System.Xml;
using System.Xml.XPath;
using ASB.CBO.DA;
using System.Text;
using System.IO;


namespace ASBBank.FNC.BP.Balance
{
	/// <summary>
	/// Summary description for Alert.  
	/// </summary>
	/// 

	#region Alert object
	
	public class Alerts
	{
		public Alerts()
		{
			
		}	
	
		#region Public Methods

		//Retrieve alerts data
		public static string GetCustomerAlerts(string sAppID, string sChannelID, string  sHOSTUserName, int iCustomerNumber, out CustomerAlerts oCustomerAlerts)
		{
			string sResult;
			string sResultXML = string.Empty;
			oCustomerAlerts = null;
			
			ASB.BC.Customer.IAlert_2008_1 oAlert = null;
			
			try
			{
				oAlert = new ASB.BC.Customer.Alert();

				sResult = oAlert.ListCustomerAlertRequests(sAppID, sChannelID, sHOSTUserName, iCustomerNumber, out sResultXML);
				if (sResult == Constants.SUCCESS)
				    oCustomerAlerts = CreateAlertObject(sResultXML);
			}
			finally
			{
				if (oAlert != null)
					ServicedComponent.DisposeObject((ServicedComponent)oAlert);
			}

			return sResult;
		}		

		//Retrieve alert delivery Details for the customer 
		public static string GetCustomerDeliveryDetails(string sAppID, string sChannelID, string  sHOSTUserName, int iCustomerNumber, out CustomerDeliveryDetails oCustomerDeliveryDetails)
		{
			string sResult;
			string sResultXML = "";
			
			ASB.BC.Customer.IAlert_2008_1 oAlert = null;
			
			try
			{
				oAlert = new ASB.BC.Customer.Alert();
				sResult = oAlert.GetCustomerDeliveryDetails(sAppID, sChannelID, sHOSTUserName, iCustomerNumber, out sResultXML);

				oCustomerDeliveryDetails = CreateDeliveryObject(sResultXML);
			}
			finally
			{
				if (oAlert != null)
					ServicedComponent.DisposeObject((ServicedComponent)oAlert);
			}

			return sResult;
		}


		//Update/Insert/Delete Alerts
		public static string ResetCustomerAlerts(string sAppID, string sChannelID, string  sHOSTUserName, 
			int iCustomerNumber, string sParametersXML, string sStaffName)
		{
			string sResult;
			
			ASB.BC.Customer.IAlert_2008_1 oAlert = null;
			
			try
			{
				oAlert = new ASB.BC.Customer.Alert();

				sResult = oAlert.SetCustomerAlertRequests(sAppID, sChannelID, sHOSTUserName,
					iCustomerNumber, sParametersXML, sStaffName);
			}
			finally
			{
				if (oAlert != null)
					ServicedComponent.DisposeObject((ServicedComponent)oAlert);
			}

			return sResult;
		}

		//Setting alerts medium before inserting new alerts or edit alert address
		public static string SetAlertMedium(string sAppID, string sChannelID, string  sHOSTUserName, 
			int iCustomerNumber, string sAlertMedium, string sAlertAddress, bool bAlertSuspended, string sStaffName)
		{
			string sResult;
			
			ASB.BC.Customer.IAlert_2008_1 oAlert = null;
			
			try
			{
				oAlert = new ASB.BC.Customer.Alert();

				sResult = oAlert.SetCustomerDeliveryDetails(sAppID, sChannelID, sHOSTUserName,
					iCustomerNumber, sAlertMedium, sAlertAddress, bAlertSuspended, sStaffName);
			}
			finally
			{
				if (oAlert != null)
					ServicedComponent.DisposeObject((ServicedComponent)oAlert);
			}

			return sResult;
		}

		//Setting alerts fee account before inserting new alerts or when edit account fee
		public static string SetAlertFeeAccount(string sAppID, string sChannelID, string  sHOSTUserName, 
			int iCustomerNumber, string sAlertFeeAccount, bool bAlertFeeExempt, int iAlertStatus, string sStaffName)
		{
			string sResult;
			
			ASB.BC.Customer.IAlert_2008_1 oAlert = null;
			
			try
			{
				oAlert = new ASB.BC.Customer.Alert();

				sResult = oAlert.SetCustomerFeeAccount(sAppID, sChannelID, sHOSTUserName,
					iCustomerNumber, sAlertFeeAccount, bAlertFeeExempt, iAlertStatus, sStaffName);
			}
			finally
			{
				if (oAlert != null)
					ServicedComponent.DisposeObject((ServicedComponent)oAlert);
			}

			return sResult;
		}

		#endregion

		#region private Methods		

		private static CustomerAlerts CreateAlertObject(string sAlertXml)
		{
			CustomerAlerts oCustomerAlerts = null;
			
			//remove customerCIF node to prepare xml for deserialization.
			string sInputXml = RemoveCustomerNode(sAlertXml);

			XmlDocument oAlertsDoc = new XmlDocument();			
			oAlertsDoc.LoadXml(sInputXml);
			XmlNode acctNode = oAlertsDoc.SelectSingleNode("//alertAccount");
			if(acctNode != null)
			{				
				oCustomerAlerts = CustomerAlerts.Create(sInputXml);
			}

			return oCustomerAlerts;
		}

		private static CustomerDeliveryDetails CreateDeliveryObject(string sDeliveryXml)
		{
			CustomerDeliveryDetails oCustomerDeliveryDetails = new CustomerDeliveryDetails();

			XmlDocument oDeliveryDoc = new XmlDocument();			
			oDeliveryDoc.LoadXml(sDeliveryXml);
			XmlNode deliveryNode = oDeliveryDoc.SelectSingleNode("//alertDeliveryDetails");
			XmlNode mediumNode = oDeliveryDoc.SelectSingleNode("//alertDeliveryDetails/alertMedium");
			if(mediumNode != null && deliveryNode != null)
			{
				oCustomerDeliveryDetails = CustomerDeliveryDetails.Create(oDeliveryDoc.SelectSingleNode("//parentXml").InnerXml);
			}

			return oCustomerDeliveryDetails;
		}
		
		private static string RemoveCustomerNode(string sAlertXml)
		{	
			XmlDocument oAlertsDoc = new XmlDocument();			
			oAlertsDoc.LoadXml(sAlertXml);
			XmlNode custNode = oAlertsDoc.SelectSingleNode("//customerCIF");
			if(custNode != null)
			{
				oAlertsDoc.SelectSingleNode("//alertRequests").RemoveChild(custNode);
				XmlNodeList alertNodeList = oAlertsDoc.SelectNodes("//alertRequest");
			}
			
			return oAlertsDoc.SelectSingleNode("//parentXml").InnerXml;  
		}		
		
		#endregion
	}

	#endregion		

}
