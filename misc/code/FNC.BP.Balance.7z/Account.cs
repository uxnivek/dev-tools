using System;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace ASBBank.FNC.BP.Balance
{
	/// <summary>
	/// Summary description for Account.
	/// </summary>
	[Serializable]
	[XmlRoot("Section_CPID")]
	public class FeeAccountDetail
	{

		public static FeeAccountDetail Create(string accountName, XmlNode xnode)
		{
			string xml = xnode.OuterXml;
			FeeAccountDetail fd = (FeeAccountDetail)ASB.CBO.Utility.XmlHelper.Inflate(xml, typeof(FeeAccountDetail));
			fd.AccountName = accountName;
			return fd;
		}

		private string accountName;
		[XmlIgnore]
		public string AccountName
		{
			get { return accountName;}
			set { accountName = value;}
		}

		private string acctUniqueNzbaNumb;
		[XmlElement("AcctUniqueNzbaNumb")]
		public string AcctUniqueNzbaNumb
		{
			get {return acctUniqueNzbaNumb;}
			set {acctUniqueNzbaNumb = value;}
		}
		
		private string acctSufxNzbaNumb;
		[XmlElement("AcctSufxNzbaNumb")]
		public string AcctSufxNzbaNumb
		{
			get {return acctSufxNzbaNumb;}
			set {acctSufxNzbaNumb = value;}
		}
		
		private string acctAccessNumb;
		[XmlElement("AcctAccessNumb")]
		public string AcctAccessNumb
		{
			get {return acctAccessNumb;}
			set {acctAccessNumb = value;}
		}
		
		private string prodDescription;
		[XmlElement("ProdDescription")]
		public string ProdDescription
		{
			get {return prodDescription;}
			set {prodDescription = value;}
		}

		private string personalisedName;
		/// <summary>Gets the personalised name of this account.</summary>
		[XmlElement("AcctPersonalisedName")]
		public string PersonalisedName
		{
			get { return personalisedName; }
			set { personalisedName = value; }
		}

		private int productNumber;
		[XmlElement("ProductNumber")]
		public int ProductNumber
		{
			get { return productNumber; }
			set { productNumber = value; }
		}

	}

	[Serializable]
	// TTW 46159 - Changed root node from "root" tp "xmlResults"
	[XmlRoot("xmlResults")]
	public class BillPaymentFeeAccountResponse
	{
		public static BillPaymentFeeAccountResponse Create(string xml)
		{
			return (BillPaymentFeeAccountResponse)ASB.CBO.Utility.XmlHelper.Inflate(xml, typeof(BillPaymentFeeAccountResponse));
		}
		
		// TTW 46159 - Changed element node from "Record" to "Section_427S"
		[XmlElement("Section_427S")]
		public BillPaymentFeeAccount[] billPaymentFeeAccountArray = null;

		public string XML
		{
			get { return ASB.CBO.Utility.XmlHelper.Deflate(this); }
		}
	}

	[Serializable]
	public class BillPaymentFeeAccount
	{
		// TTW 46159 - Changed element nodes "NZBAAccountSuffix" to "AcctSufxNumb" and
		//             "Product_Short_Name" to "ProdShortName"
		[XmlElement("AcctSufxNumb")]
		public string NZBAAccountSuffix;
		[XmlElement("ProdShortName")]
		public string Product_Short_Name;
		
		public string PersonalisedName 
		{
			/* Example of a record used to create a BillPaymentFeeAccount object.
			   Note how Product_Short_Name contains the personalised name in brackets, if it is available.
<Record>
  <NZBAAccountSuffix>50</NZBAAccountSuffix> 
  <Product_Short_Name>FASTS(fast 50)</Product_Short_Name> 
</Record>
			*/
			get 
			{
				int openBracketIndex = Product_Short_Name.IndexOf('(');
				int closeBracketIndex = Product_Short_Name.IndexOf(')');
				if (openBracketIndex < 0 || closeBracketIndex < 0 || openBracketIndex > closeBracketIndex || closeBracketIndex - openBracketIndex == 1) 
				{
					return null;
				}
				else 
				{
					// return the contents of the brackets, excluding the brackets
					return Product_Short_Name.Substring(openBracketIndex + 1, closeBracketIndex - openBracketIndex - 1);
				}
			}
		}
	}

	[Serializable]
	public class Section_CPID
	{
		public static Section_CPID Create(string xml)
		{
			return (Section_CPID)ASB.CBO.Utility.XmlHelper.Inflate(xml, typeof(Section_CPID));
		}

		[XmlElement("AcctUniqueNzbaNumb")]
        public string AcctUniqueNzbaNumb;
		[XmlElement("AcctSufxNzbaNumb")]
		public string AcctSufxNzbaNumb;
		[XmlElement("AcctAccessNumb")]
		public string AcctAccessNumb;
		[XmlElement("ProdNumb")]
		public string ProdNumb;
		[XmlElement("PitmHoldExistsFlag")]
		public string PitmHoldExistsFlag;
		[XmlElement("AcctLedgerBalAmt")]
		public string AcctLedgerBalAmt;
		[XmlElement("AcctAvailableBalAmt")]
		public string AcctAvailableBalAmt;
		[XmlElement("AcctTargetFundsAmt")]
		public string AcctTargetFundsAmt;
		[XmlElement("AcctOvdtLimitFormalAmt")]
		public string AcctOvdtLimitFormalAmt;
		[XmlElement("AcctClosedFlag")]
		public string AcctClosedFlag;
		[XmlElement("AcctFeeFlag")]
		public string AcctFeeFlag;
		[XmlElement("SuppressStmtFlag")]
		public string SuppressStmtFlag;
		[XmlElement("StmtSuppressableFlag")]
		public string StmtSuppressableFlag;
		[XmlElement("SigtReqd")]
		public string SigtReqd;
		[XmlElement("ProdAttributes")]
		public string ProdAttributes;
		[XmlElement("ProdDescription")]
		public string ProdDescription;
	}


	[Serializable]
	public class AccountAddress 
	{

		#region Fields
		string _nzbaAccountNumber;
		string _accountName;
		string _address;
	    public string AssociateAccountNumber { get; set; }
		#endregion

		#region Properties
		public string NzbaAccountNumber
		{
			get { return _nzbaAccountNumber;}
			set { _nzbaAccountNumber = value; }
		}
		public string AccountName
		{
			get { return _accountName;}
			set { _accountName = value; }
		}
		public string Address
		{
			get { return _address;}
			set { _address = value; }
		}
		public bool HasAddress 
		{
			get { return _address != null && _address.Length > 0; }
		}
		#endregion

	}


}
